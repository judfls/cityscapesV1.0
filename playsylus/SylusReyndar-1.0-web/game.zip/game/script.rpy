﻿#I started making this game on 3/27/2026

default choiceday2tv = False
default deadneighbour = False
default flashlight = False
default hmh = 0
default dream = 0
default seb = False
default paper = False
default end1 = False
default end2 = False
default end3 = False
default end4 = False

image bg bedroom = "bedroom.png"
image bg black = "black.jpg"
image bg white = "white.png"
image bg door = "door.png"
image bg doord = "doord.png"
image bg halld = "halld.png"
image bg staird = "staird.png"
image bg doord2 = "doord2.png"
image bg bathroom = "bathroom.png"
image bg phonel = "phonel.png"
image bg phoned = "phone.png"
image bg livingroom = "livingroom.png"
image bg livingroomseb = "livingroomseb.png"
image bg hole1 = "hole1.png"
image bg hole2 = "hole2.png"
image bg hole3 = "hole3.png"
image bg hole4 = "hole4.png"
image bg tunnel1 = "tunnel1.png"
image bg tunnel2 = "tunnel2.png"

image bg island = "island3.png"

image bg tvnews = "tvnews.png"
image bg tvweather = "tvweather.png"
image bg tvweather2 = "tvweather2.png"
image bg tvstatic = "tvnoise.png"
image bg tv = "tv.png"
image bg tvno = "tvno.png"

image bg peep = "peep.png"
image bg p_neighbour = "char/p_neighbour2.png"
image bg p_hatman = "char/p_hatmanangry.png"
#image bg p_hatman2 = "char/p_hatmanangry2.png"
#image bg p_hatman3 = "char/p_hatmanangry3.png"
#image bg p_hatman4 = "char/p_hatmanangry4.png"
#image bg p_hatman5 = "char/p_hatmanangry5.png"
image bg p_ipod = "char/p_ipodman.png"
image bg p_police = "char/p_police.png"
image bg p_death = "char/p_death.png"
image bg p_seb = "char/p_seb.png"

image phage:
    "images/phage1.png"
    pause 3.0
    "images/phage2.png"
    pause 0.1
    "images/phage1.png"
    pause 4.0
    "images/phage2.png"
    pause 0.1
    "images/phage1.png"
    pause 3.0
    "images/phage2.png"
    pause 0.1
    "images/phage1.png"
    pause 0.2
    "images/phage2.png"
    pause 0.1
    repeat

image phage2:
    "images/phage1.png"
    pause 0.1
    "images/phage4.png"
    pause 0.1
    "images/phage3.png"
    pause 0.1
    "images/phage2.png"
    pause 0.1
    "images/phage5.png"
    pause 0.1
    "images/phage1.png"
    pause 0.1
    "images/phage3.png"
    pause 0.1
    "images/phage2.png"
    pause 0.1
    repeat



define nc = Character('Newscaster')
define nb = Character('Neighbour')
define qu = Character("???") 
define ar = Character("Arthur") 
define hm = Character("Hat Man") 
define ni = Character("911 Operator") 
define sb = Character("Seb") 


label start:
    $ quick_menu = False
    play music "audio/stump.mp3" fadein 2.0
    jump day7
    scene bg black with Dissolve(0.5)
    "It's Tuesday."
    scene bg bedroom with Dissolve(0.5)
    "You had a dream last night that you would like to forget for now."
    "You decide to turn the television on."
    scene bg tvnews with Dissolve(0.5)
    "The newscaster speaks to you."
    nc "Breaking news tonight: Scientists have detected unusual and widespread tectonic plate movement across the globe."
    nc "Authorities are urging residents to remain vigilant for potential seismic activity throughout the day."
    nc "We'll have more on this story after your local forecast. I'm Matthew Nicholson, and this is Channel 9 News."
    scene bg tv
    "You turn the TV off."
    "..."
    play sound "audio/knock.mp3"
    "You hear a knock from the door."
    scene bg door with Dissolve(0.5)
    "You look through the peep hole."
    scene bg p_neighbour with Dissolve(0.5)
    nb "Hey, neighbour."
    nb "How are you doing in there?"
    menu:
        "Fine.":
            nb "Good."
            jump after_menu
        "Bad.":
            nb "Well I'm not doing so hot either."
            jump after_menu
    return

label after_menu:
    nb "Have you heard about the earthquakes?"
    menu:
        "Yeah.":
            nb "Just wanted to check on you."
            nb "Keep in touch."
            jump after_menu2
        "Do you know what's going on?":
            nb "Quite honestly, I have no idea."
            nb "I think we should just wait it out."
            jump after_menu2
    return

label after_menu2:
    nb "You can contact me at 780-444-543."
    nb "See you around."
    scene bg peep with Dissolve(0.5)
    "..."
    scene bg livingroom with Dissolve(0.5)
    "It's 12:00pm."
   
label day1:
    scene bg livingroom with Dissolve(0.5)
    menu:
        "Play the crossword.":
            "It's very boring."
            "At least it's a good time killer."
            jump day1
        "Call someone.":
            scene bg phonel with Dissolve(0.5)
            menu:
                "Call your neighbour.":
                    nb "Who is this?"
                    menu:
                        "This is your neighbour. Just checking if this number is right.":
                            nb "I think it's working great."
                            "..."
                            nb "Have a good rest of your day."
                            jump day1
                        "This is a ghost.":
                            nb "Don't scare me."
                            jump day1
                "Call 911.":
                    "Phone" "No lines availible currently."
                    jump day1
                "Nevermind.":
                    jump day1
        "Clean up.":
            "You cleaned up around the house."
            jump day1

        "Take a shower.":
            scene bg bathroom with Dissolve(0.5)
            "There's hot water and soap."
            "You feel refreshed."
            jump day1
        
        "Watch TV.":
            scene bg tvnews with Dissolve(0.5)
            nc "A 5.2 magnitude earthquake has struck the central Pacific Ocean, one of several seismic events recorded globally. 
            The quake has triggered multiple tsunamis, with coastal regions across Asia now on high alert."
            nc "Stay alert. This is Matthew Nicholson with Channel 9 News."
            jump day1

        "Go to bed.":
            jump day1end

label day1end:
    scene bg bedroom with Dissolve(0.5)
    stop music fadeout 2.0
    "Don't let the bed bugs bite."
    scene bg black with Dissolve(0.5)
    pause 3.0

label day2start:
    play music "audio/stump.mp3" fadein 2.0
    "It's Wednesday."
    scene bg bedroom with Dissolve(0.5)
    "You had that same dream."
    menu:
        "Try to remember.":
            scene bg black with Dissolve(0.5)
            stop music fadeout 2.0
            "You woke up in your bed..."
            play sound "audio/knock.mp3"
            scene bg doord with Dissolve(1)
            "And heard a knock at the door."
            "You got up.."
            "And.."
            stop sound
            scene bg black with Dissolve(0.5)
            "You forgot."
            play music "audio/stump.mp3" fadein 2.0
            $ dream += 1
            jump day2tv

        "Get on with your day.":
            jump day2tv

label day2tv:
    "You decide to turn the television on."
    scene bg tvnews with Dissolve(0.5)
    nc "Good morning. Officials are advising residents to stay home today as seismic activity in the region continues to increase."
    nc "A new report has revealed unusual pulses emanating from deep within the Earth. A phenomenon scientists are calling the \"Earth Heartbeat.\""
    nc "Stay safe, remain vigilant, and please stay indoors. I'm Matthew Nicholson, and this is Channel 9 News."
    scene bg tv
    play sound "audio/knock.mp3"
    "You hear a knock at the door."
    scene bg door with Dissolve(0.5)
    "You look through the peep hole."
    scene bg p_hatman with Dissolve(0.5)
    qu "Hello?"
    qu "Can I trust you?"
    menu:
        "Sure.":
            qu "Thank you."
        "You look horrible.":
            qu "What makes me is not my choice."
        "What's with the huge hat?":
            qu "See the wreck within me."
    qu "My child, Phage is here."
    qu "Destiny awaits."
    qu "Be careful."
    menu:
        "Who are you?":
            qu "Can't tell yet."
            qu "You learn in due time."
        "Scram.":
            qu "..."
    qu "I'll be back."
    scene bg peep with Dissolve(0.5)
    "..."
    scene bg door with Dissolve(0.5)
    play sound "audio/knock.mp3"
    "Another knock comes from the door."
    scene bg p_ipod with Dissolve(0.5)
    qu "Hey."
    qu "I saw that guy come over here."
    qu "He's been disturbing people all around the apartment."
    qu "My name's Arthur by the way."
    ar "He says \"The Phage is coming, the Phage is coming\" like a broken fucking record."
    ar "He says the first door he picks is the \"Desired one.\""
    ar "Do what he says."
    scene bg peep with Dissolve(0.5)
    "..."
    scene bg livingroom with Dissolve(0.5)
    "It's 2:00pm."
label day2:
    scene bg livingroom with Dissolve(0.5)
    menu:
        "Play sudoku.":
            "It's very boring."
            "At least it's a good time killer."
            jump day2
        "Call someone.":
            scene bg phonel with Dissolve(0.5)
            menu:
                "Call your neighbour.":
                    nb "Hey neighbour. How's it treating you?"
                    menu:
                        "There is some weird guy going around with a huge hat. Have you seen him?":
                            nb "I think so."
                            "..."
                            nb "Yeah... yeah, I saw him doing laundry once."
                            nb "Weird guy."
                            jump day2
                        "What is \"Phage\"?":
                            nb "No clue."
                            jump day2
                "Call 911.":
                    "Phone" "No lines availible currently."
                    jump day2
                "Nevermind.":
                    jump day2

        "Clean up.":
            "There's nothing to clean."
            jump day2

        "Take a shower.":
            scene bg bathroom with Dissolve(0.5)
            "There's hot water and soap."
            "Your pipes are creaking."
            jump day2
        
        "Watch TV." if not choiceday2tv:
            scene bg tvweather with Dissolve(0.5)
            "Weatherman" "A dangerous heat event is sweeping across the country, {cps=25}with temperatures reaching a severe 42° Celsius. {/cps}
            {cps=20}Health officials are urging residents, particularly the elderly and young children,{/cps} {cps=15}to avoid prolonged outdoor exposure, 
            stay hydrated,{cps=10} and seek air-conditioned{/cps} {cps=5}shelter where possible.{/cps}"
            stop music fadeout 5.0
            scene bg tvweather2 with Dissolve(5)
            "Weatherman" "{cps=5}Death is a low yet juicy fruit. Decide your fate from the tree. The branches tell you. You. I know you. You are... needed.{/cps}"
            scene bg tvstatic with Dissolve(1)
            pause 3.0
            $ choiceday2tv = True
            jump day2

        "Go to bed.":
            jump day2end
label day2end:
    scene bg bedroom with Dissolve(0.5)
    stop music fadeout 2.0
    "Sleep tight."
    scene bg black with Dissolve(0.5)
    pause 3.0

label day3start:
    play music "audio/stump.mp3" fadein 2.0
    "It's Thursday."
    scene bg bedroom with Dissolve(0.5)
    "You had that same dream."
    menu:
        "Try to remember.":
            scene bg black with Dissolve(0.5)
            stop music fadeout 2.0
            "You woke up in your bed..."
            play sound "audio/knock.mp3"
            scene bg doord with Dissolve(1)
            "And heard a knock at the door."
            "You got up.."
            "And.."
            "Opened the door.."
            scene bg halld with Dissolve(1)
            "But.."
            stop sound
            scene bg black with Dissolve(0.5)
            "You forgot."
            play music "audio/stump.mp3" fadein 2.0
            $ dream += 1
            jump day3tv
           
        "Get on with your day.":
            "It's better that way."
            jump day3tv

label day3tv:
    "You decide to turn the television on."
    scene bg tvnews with Dissolve(0.5)
    nc "Authorities are issuing an urgent message to all residents at this time: please remain calm and stay indoors until further notice."
    nc "Officials are strongly advising the public to avoid any and all outdoor activity, as conditions outside remain extremely dangerous."
    nc "Do not attempt to leave your home, and under no circumstances should you allow unfamiliar individuals to enter your residence."
    play sound "audio/earthquake.mp3"
    nc "Lock your doors and keep your windows shut. Emergency personnel are actively working to address the situation, and updates will be provided as more information becomes available." 
    nc "We urge everyone to remain patient, stay vigilant, and above all... stay safe. We will continue to bring you live coverage of this developing story as it unfolds."
    nc "I'm Matthew Nicholson, and this is Channel 9 News."
    scene bg tv
    play sound "audio/knock.mp3"
    "You hear a knock at the door."
    scene bg door with Dissolve(0.5)
    "You look through the peep hole."
    scene bg p_hatman with Dissolve(0.5)
    hm "So I see you again."
    hm "You need to help me."
    menu:
        "Yes.":
            hm "Good."
            hm "A man will come to your door today."
            hm "Do not let him in."
            $ hmh += 1
        
        "No.":
            hm "You've killed us."
    hm "Goodbye."
    scene bg peep with Dissolve(0.5)
    "..."
    scene bg door with Dissolve(0.5)
    play sound "audio/knock.mp3"
    "Another knock comes from the door."
    scene bg p_police with Dissolve(0.5)
    "Policeman" "This is the police. Open the door."
    "..."
    "Policeman" "Open up."
    menu:
        "Open the door.":
            scene bg black with Dissolve(0.5)
            stop music fadeout 0.5
            play sound "audio/door.mp3"
            pause 5
            play sound "audio/shot.mp3"
            pause 3
            return
        "Keep quiet.":
            "Policeman" "Open the fucking door."
            play sound "audio/knock.mp3"
            "Policeman" "Please."
            menu:
                "Open the door.":
                    scene bg black with Dissolve(0.5)
                    stop music fadeout 0.5
                    play sound "audio/door.mp3"
                    pause 5
                    play sound "audio/shot.mp3"
                    pause 3
                    return
                "Keep quiet.":
                    $ hmh += 1
                    pause 3
    scene bg peep with Dissolve(0.5)
    "..."
    scene bg door with Dissolve(0.5)
    play sound "audio/knock.mp3"
    "Another knock comes from the door."
    scene bg p_ipod with Dissolve(0.5)
    ar "You got any sugar?"
label sugaripod:
    menu:
        "No.":
            ar "Ok."

        "Yeah sure, here.":
            ar "Thank you."

        "Shouldn't you be inside?":
            ar "Whatever."
            jump sugaripod

    scene bg livingroom with Dissolve(0.5)
    "It's 3:00pm"

label day3:
    scene bg livingroom with Dissolve(0.5)
    menu:
        "Play shikaku.":
            "It's very fun, actually."
            "And it's a good time killer."
            jump day3
        "Call someone.":
            scene bg phonel with Dissolve(0.5)
            menu:
                "Call your neighbour." if not deadneighbour:
                    nb "Hey neighbour. What's going on?"
                    menu:
                        "Nothing much. How are you doing?":
                            nb "Hold on. Someone is at my door."
                            play sound "audio/neighbour_phone_shot.mp3"
                            pause 17
                            $ deadneighbour = True
                            jump day3
                        
                "Call 911.":
                    "Phone" "No lines availible currently."
                    jump day3
                "Nevermind.":
                    jump day3

        "Clean up.":
            "You find a small hole in your wall."
            show bg hole1 with Dissolve(0.5)
            menu:
                "Look through the hole.":
                    "It's too dark to see anything."
                    jump day3
                "Ignore it.":
                    jump day3
            jump day3

        "Take a shower.":
            scene bg bathroom with Dissolve(0.5)
            "There's hot water but barely any soap."
            "Your pipes are still creaking."
            jump day3
        
        "Watch TV.":
            scene bg tvstatic with Dissolve(0.5)
            pause 3.0
            jump day3
           

        "Go to bed.":
            jump day3end

label day3end:
    scene bg bedroom with Dissolve(0.5)
    stop music fadeout 2.0
    "Time to hit the hay."
    scene bg black with Dissolve(0.5)
    pause 3.0

label day4start:
    play music "audio/stump.mp3" fadein 2.0
    "It's Friday."
    scene bg bedroom with Dissolve(0.5)
    "You had that same dream."
    menu:
        "Try to remember.":
            scene bg black with Dissolve(0.5)
            stop music fadeout 2.0
            "You woke up in your bed..."
            play sound "audio/knock.mp3"
            scene bg doord with Dissolve(1)
            "And heard a knock at the door."
            "You got up and opened the door."
            scene bg halld with Dissolve(1)
            "But..."
            "No one was there."
            "You.."
            "Walked."
            "To the.."
            stop sound
            scene bg black with Dissolve(0.5)
            "You forgot."
            play music "audio/stump.mp3" fadein 2.0
            $ dream += 1
            jump day4tv
           
        "Get on with your day.":
            "It's better that way."
            jump day4tv

label day4tv:
    "You decide to turn the television on."
    scene bg tvstatic with Dissolve(0.5)
    pause 3.0
    play sound "audio/knock.mp3"
    "You hear a knock at the door."
    scene bg door with Dissolve(0.5)
    "You look through the peep hole."
    scene bg p_ipod with Dissolve(0.5)
    ar "Did you hear what happened to Colin?"
    menu:
        "Who is Colin?":
            ar "Your next door neighbour."
            ar "He was found dead."

        "What happened?":
            ar "He was found dead."
    ar "They say it was that \"Policeman\" who came into the building yesterday."
    ar "Thank God I turned him away."
    ar "I guess you did too."
    ar "Be careful."
    ar "Things are getting pretty crazy out here."
    ar "Here. Have my number. It's 825-293-182."
    scene bg peep with Dissolve(0.5)
    "..."
    scene bg door with Dissolve(0.5)
    play sound "audio/knock.mp3"
    "Another knock comes from the door."
    scene bg p_death with Dissolve(0.5)
    qu "{cps=10}Life is the harbinger of death.{/cps}"
    qu "{cps=10}Remember.{/cps}"
    qu "{cps=10}Do not overstay your welcome.{/cps}"
    qu "{cps=10}You'll be dead soon anyway.{/cps}"
    qu "{cps=10}The end is a beginning.{/cps}"
    scene bg peep with Dissolve(0.5)
    "..."
    scene bg door with Dissolve(0.5)
    play sound "audio/knock.mp3"
    "Another knock comes from the door."
    scene bg p_hatman with Dissolve(0.5)
    hm "I need more help."
    menu:
        "Yes.":
            hm "Good."
            hm "Take your opertunity on day six."
            hm "Do not be frightened by what you see."
            hm "You'll need this."
            menu:
                "Take the flashlight.":
                    hm "Don't get forgetful now."
                    $ flashlight = True
                    $ hmh += 1
                "Refuse.":
                    hm "..."
        
        "No.":
            hm "You've killed us."
    hm "Goodbye."
    scene bg livingroom with Dissolve(0.5)
    "You're halfway through your food supply."
    "It's 2:00pm."

    label day4:
    scene bg livingroom with Dissolve(0.5)
    menu:
        "Play wordsearch.":
            "Your aunt gave you these."
            play sound "audio/earthquake.mp3" 
            "They remind you of better times."
            jump day4
        "Call someone.":
            scene bg phonel with Dissolve(0.5)
            menu:
                "Call Arthur.":
                    ar "Hello?"
                    "Muffled noises of china breaking come from the telephone."
                    ar "Oh well.."
                    jump day4
                        
                "Call 911.":
                    ni "911, What's your emergency?"
                    menu:
                        "Some man dressed in a police uniform just killed my neighbour.":
                            "Beep."
                        
                        "Do you know what is going on?":
                            "Beep."

                    jump day4
                "Nevermind.":
                    jump day4

        "Clean up.":
            "You look at the hole in your wall again."
            "It seems to have gotten bigger."
            show bg hole2 with Dissolve(0.5)
            menu:
                "Look through the hole.":
                    "It's too dark to see anything."
                    if flashlight:
                        "You could use your flashlight to see better."
                        menu:
                            "Use the flashlight.":
                                "The hole tunnels into the wall and goes on for a while."
                            "Nevermind.":
                                pass
                    jump day4
                "Ignore it.":
                    jump day4

        "Take a shower.":
            scene bg bathroom with Dissolve(0.5)
            "No more soap."
            jump day4
        
        "Watch TV.":
            scene bg tvstatic with Dissolve(0.5)
            pause 3.0
            jump day4
           

        "Go to bed.":
            jump day4end

label day4end:
    scene bg bedroom with Dissolve(0.5)
    stop music fadeout 2.0
    "Welp, the sheep ain't gonna count themselves."
    scene bg black with Dissolve(0.5)
    pause 3.0

label day5start:
    play music "audio/stump.mp3" fadein 2.0
    "It's Saturday."
    scene bg bedroom with Dissolve(0.5)
    "You had that same dream."
    menu:
        "Try to remember.":
            scene bg black with Dissolve(0.5)
            stop music fadeout 2.0
            "You woke up in your bed..."
            play sound "audio/knock.mp3"
            scene bg doord with Dissolve(1)
            "And heard a knock at the door."
            "You got up and opened the door."
            scene bg halld with Dissolve(1)
            "But no one was there."
            "You walked."
            "To the.."
            "Stairs."
            scene bg staird with Dissolve(1)
            "You walked down the stairs."
            scene bg doord2 with Dissolve(1)
            "And.."
            "Wait.."
            stop sound
            scene bg black with Dissolve(0.5)
            "You forgot."
            play music "audio/stump.mp3" fadein 2.0
            $ dream += 1
            jump day5tv
           
        "Get on with your day.":
            "It's better that way."
            jump day5tv

label day5tv:
    "You decide to turn the television on."
    scene bg tv with Dissolve(0.5)
    pause 3.0
    play sound "audio/knock.mp3"
    "You hear a knock at the door."
    scene bg door with Dissolve(0.5)
    "You look through the peep hole."
    scene bg p_seb with Dissolve(0.5)
    qu "Hey kid, I've been trekking around for a while now, trying to find a place to stay."
    qu "I don't have much, but I can share with you if you let me in."
    play sound "audio/earthquake.mp3"
    qu "My name's Seb, by the way."
label day5seb:    
    menu:
        "Yeah, sure, come on in.":
            sb "Thank you, I really appreciate it."
            sb "I sure hope you aren't one of the insane ones out here."
            play sound "audio/door.mp3"
            $ seb = True

        "What stuff do you have?":
            sb "I've got some clothes, soap, a shovel, a sleeping bag, and food."
            jump day5seb

        "Get lost.":
            sb "Oh, alright. I understand."
    scene bg peep with Dissolve(0.5)
    "..."
    scene bg door with Dissolve(0.5)
    play sound "audio/knock.mp3"
    "Another knock comes from the door."
    scene bg p_hatman with Dissolve(0.5)
    hm "One more thing."
    menu:
        "Okay.":
            hm "Good."
            hm "A show of trust."
            hm "I will enter and kill you right now, or I won't."
            hm "Your choice."
            menu:
                "Open the door.":
                    stop music fadeout 2.0
                    scene bg black  with Dissolve(0.5)
                    play sound "audio/door.mp3"
                    "He doesn't enter."
                    pause 1.0
                    "He just stands there."
                    pause 2.0
                    scene bg p_hatman with Dissolve(0.5)
                    hm "See?"
                    hm "I'll be back tomorrow."
                    play music "audio/stump.mp3" fadein 2.0
                    $ hmh += 1
                "Keep it closed.":
                    hm "Very well"
        
        "No. Stop bothering me.":
            hm "Your salvation lost."
    hm "Goodbye."
    if seb:
        scene bg livingroomseb with Dissolve(0.5)
    else:
        scene bg livingroom with Dissolve(0.5)
        "You're running out of food."
    "It's 1:00pm."

    label day5:
        if seb:
            scene bg livingroomseb with Dissolve(0.5)
        else:
            scene bg livingroom with Dissolve(0.5)
    menu:
        "Play Dots and Boxes.":
            if seb:
                "You play Dots and Boxes with Seb."
                "He's pretty good at it."
            else:
                "You play Dots and Boxes by yourself."
                "It's boring."
            jump day5
        "Call someone.":
            scene bg phonel with Dissolve(0.5)
            menu:
                "Call Arthur.":
                    ar "Hey. How's it going?"
                    menu:
                        "I let in this guy named Seb." if seb:
                            ar "Alright, make sure he doesn't cause any trouble."
                            ar "I might have to file a noise complaint."
                            ar "Only joking."
                            jump day5
                        "This guy named Seb came around asking to come in." if not seb:
                            ar "He just knocked on my door and asked to come in."
                            ar "I let him in."
                            ar "Nice guy."
                            ar "Really bad at Hangman though."
                            ar "Who guesses \"J\" first?"
                            jump day5
                    jump day5
                        
                "Call 911.":
                    "Phone" "No lines availible currently."
                    jump day5
                "Nevermind.":
                    jump day5

        "Clean up.":
            "You look at the hole in your wall again."
            "It seems to have gotten even bigger."
            show bg hole3 with Dissolve(0.5)
            if seb:
                sb "What the hell is that?"
            else:
                "..."
            menu:
                "Look through the hole.":
                    "It's too dark to see anything."
                    if flashlight:
                        "You could use your flashlight to see better."
                        menu:
                            "Use the flashlight.":
                                "The hole tunnels into the wall and goes on for a while."
                                "You hear a distant murmuring coming from the hole."
                            "Nevermind.":
                                pass
                    jump day5
                "Ignore it.":
                    jump day5

        "Take a shower.":
            scene bg bathroom with Dissolve(0.5)
            if seb:
                "You use Seb's soap."
                "He also fixed the heater for you."
                "Nice guy."
                jump day5
            else:
                "The water's cold now."
                "Also you're out of soap."
            jump day5
        
        "Watch TV.":
            if seb:
                scene bg tvnews with Dissolve(0.5)
                "Seb fixes the TV for you."
                "You and Seb watch TV together."
                "It's nice to have some company."
                nc "We're getting reports of a new seismic event, with an estimated magnitude of 6.8. The epicenter is located near the city of San Francisco, and residents are being urged to take immediate precautions."
                sb "Can we turn this off? I don't want to hear about it."
                jump day5
            else:
                scene bg tv with Dissolve(0.5)
                pause 3.0
                jump day5
            jump day5
           

        "Go to bed.":
            jump day5end

label day5end:
    scene bg bedroom with Dissolve(0.5)
    stop music fadeout 2.0
    "It's Bedtime for Bonzo."
    scene bg black with Dissolve(0.5)
    pause 3.0

label day6start:
    play music "audio/stump.mp3" fadein 2.0
    "It's Sunday."
    scene bg bedroom with Dissolve(0.5)
    "You had that same dream."
    menu:
        "Try to remember.":
            scene bg black with Dissolve(0.5)
            stop music fadeout 2.0
            "You woke up in your bed..."
            play sound "audio/knock.mp3"
            scene bg doord with Dissolve(1)
            "And heard a knock at the door."
            "You got up and.."
            "Opened the door.."
            scene bg halld with Dissolve(1)
            "But no one was there."
            "You walked to the stairs"
            "Stairs."
            scene bg staird with Dissolve(1)
            "You walked down the stairs."
            stop sound fadeout 0.5
            scene bg doord2 with Dissolve(1)
            "And.."
            if dream >= 4:
                menu:
                    "Open the door.":
                        show bg white with Dissolve(3)
                        pause 0.5
                        play music "audio/end1-1.wav"
                        pause 3.0
                        jump end1
                    "Keep it closed.":
                        show bg black with Dissolve(3)
                        "It's better that way."
                        play music "audio/stump.mp3" fadein 2.0
                        jump day6tv
            else:
                "Wait.."
                "You should have remembered more."
            stop sound
            scene bg black with Dissolve(0.5)
            "You forgot."
            play music "audio/stump.mp3" fadein 2.0
            jump day6tv
           
        "Get on with your day.":
            "It's better that way."
            jump day6tv

label day6tv:
    "You decide to turn the television on."
    if seb:
        scene bg tvnews with Dissolve(0.5)
        nc "Death toll rises to 500 after devastating earthquake strikes downtown area. Rescue efforts continue as authorities work tirelessly to provide aid and support to those affected by the disaster."
        sb "C'mon man, can we change the channel?"
        sb "It's too depressing."
    else:
        scene bg tv with Dissolve(0.5)
    pause 3.0
    play sound "audio/knock.mp3"
    "You hear a knock at the door."
    scene bg door with Dissolve(0.5)
    "You look through the peep hole"
    scene bg p_hatman with Dissolve(0.5)
    if hmh >= 4:
        hm "You've been good to me."
        hm "I don't have much left to give you, but you'll need this."   
        menu:
            "Take piece of paper.":
                hm "I know where your headed."
                hm "Use this to find your way."
                "The paper has numbers written on it."
                "It looks like a phone number."
                $ paper = True

            "Refuse.":
                hm "Shame."
    else:
        hm "You haven't done enough for me yet."
        hm "You don't trust me enough."
        hm "Goodbye."
        hm "Enjoy your last days."
    scene bg peep with Dissolve(0.5)
    "..."
    if seb:
        scene bg livingroomseb with Dissolve(0.5)
    else:
        scene bg livingroom with Dissolve(0.5)
        "You're almost completely out of food."
        "You might have enough for one more day."
    "It's 12:00pm."

    label day6:
        if seb:
            scene bg livingroomseb with Dissolve(0.5)
        else:
            scene bg livingroom with Dissolve(0.5)
    menu:
        "Play Hangman.":
            if seb:
                "You play Hangman with Seb."
                "He's pretty bad at it."
                "Who guesses \"W\" first?"
            else:
                "You play Hangman by yourself."
                "It's really easy."
            jump day6
        "Call someone.":
            scene bg phonel with Dissolve(0.5)
            menu:
                "Call Arthur.":
                    ar "Hey, whats up?"
                    menu:
                        "You should come over sometime.":
                            ar "There's nothing better to do."
                            jump day6
                    jump day6

                "Call the number on the paper." if paper:
                    "You call the number on the paper."
                    "It rings a few times before someone picks up."
                    qu "Hello?"
                    qu "The last riddle he speaks has no answer."
                    qu "You must say Phage."
                    "The line goes dead."
                    jump day6

                "Call 911.":
                    "Phone" "No lines availible currently."
                    jump day6
                "Nevermind.":
                    jump day6

        "Clean up.":
            "You look at the hole in your wall again."
            "It seems to have gotten even bigger."
            show bg hole4 with Dissolve(0.5)
            "It's big enough to fit through."
            if seb:
                sb "You aren't going in there, right?"
            else:
                "..."
            menu:
                "Walk through the hole.":
                    "It's too dark to see anything."
                    $ flashlight = True
                    if flashlight:
                        "You could use your flashlight to see better."
                        menu:
                            "Use the flashlight.":
                                jump tunnel
                            "Nevermind.":
                                jump day6
                    else:
                        jump day6
                    jump day6
                "Ignore it.":
                    jump day6

        "Take a shower.":
            scene bg bathroom with Dissolve(0.5)
            if seb:
                "You use Seb's soap."
                "He also fixed the heater for you."
                jump day6
            else:
                "The water's still cold."
                "Still out of soap."
            jump day6
        
        "Watch TV.":
            if seb:
                scene bg tvnews with Dissolve(0.5)
                nc "In a shocking turn of events, the earthquake has caused a massive sinkhole to open up in the downtown area, swallowing several buildings and trapping dozens of people inside. Rescue teams are currently working around the clock to extract survivors from the rubble, but the situation remains dire."
                sb "Oh my God, that's crazy."
                sb "What do we do?"
                jump day6
            else:
                scene bg tvstatic with Dissolve(0.5)
                pause 3.0
                jump day6
            jump day6
           

        "Go to bed.":
            jump day6end

label day6end:
    scene bg bedroom with Dissolve(0.5)
    stop music fadeout 2.0
    "Better go score some snores."
    scene bg black with Dissolve(0.5)
    pause 3.0

label day7start:
    play music "audio/stump.mp3" fadein 2.0
    "It's Monday."
    scene bg bedroom with Dissolve(0.5)
    "You didn't have any dreams last night."

label day7tv:
    "You decide to turn the television on."
    if seb:
        scene bg tvnews with Dissolve(0.5)
        nc "The sinkhole that opened up in the downtown area has continued to expand, now measuring over twenty kilometers wide and swallowing entire cities. Rescue efforts have been hampered by the unstable ground conditions, and authorities are urging residents to stay away from the area as it remains a significant danger."
        sb "Jesus christ, that's insane."
        sb "They said it was going to be bad, but I didn't think it would be this bad."
        sb "That's the size of a fucking country."
    else:
        scene bg tv with Dissolve(0.5)
    pause 3.0
    
    if seb:
        scene bg livingroomseb with Dissolve(0.5)
    else:
        scene bg livingroom with Dissolve(0.5)
        "You're completely out of food."
        "Seems like it's going to be a long day."
    "It's 9:00am."

    label day7:
        if seb:
            scene bg livingroomseb with Dissolve(0.5)
        else:
            scene bg livingroom with Dissolve(0.5)
    menu:
        "Play Bulls and Cows.":
            if seb:
                "You play Bulls and Cows with Seb."
                "He's okay at it."
            else:
                "You're too hungry."
            jump day7
        "Call someone.":
            scene bg phonel with Dissolve(0.5)
            menu:
                "Call Arthur.":
                    if seb:
                        "No answer."
                    else:
                        sb "Hey, it's Seb. I don't know if you heard, but the sinkhole has gotten really bad."
                        sb "Arthur left to go check on his mom." 
                        sb "He said he might not be back for a while."                 
                    jump day7

                "Call the number on the paper." if paper:
                    "You call the number on the paper."
                    "It rings a few times before someone picks up."
                    qu "Hello?"
                    qu "You missed your chance."
                    "The line goes dead."
                    jump day7

                "Call 911.":
                    "Phone" "No lines availible currently."
                    jump day7
                "Nevermind.":
                    jump day7

        "Clean up.":
            "The hole in your wall is now gone."
            jump day7
            

        "Take a shower.":
            scene bg bathroom with Dissolve(0.5)
            if seb:
                "You have a nice shower."
                "You think about the sinkhole."
                "You wonder if it's going to get bigger."
                jump day7
            else:
                "Why bother."
            jump day7
        
        "Watch TV.":
            if seb:
                scene bg tvnews with Dissolve(0.5)
                nc "The sinkhole has now reached the size of the entire country, and is continuing to expand at an alarming rate. Scientists are baffled by the phenomenon, and are struggling to understand the underlying causes. The situation is being described as unprecedented, and authorities are urging people to evacuate to higher ground as soon as possible."
                scene bg tvstatic with Dissolve(0.5)
                jump day7
            else:
                scene bg tvstatic with Dissolve(0.5)
                pause 3.0
                jump day7
            jump day7
           

        "Go to bed.":
            stop music fadeout 2.0
            pause 5.0
            play sound "audio/big.wav"
            pause 1.0
            show bg livingroom at Shake((1.5, 1.0, 1.5, 1.0), 10.0, dist=5)    
            pause 2.0
            scene bg white with Dissolve(6.0)
            pause 4.0
            jump end2

label end2:
    if seb:
        play music "audio/end1-1.wav"
        centered "{color=#000000}This is the end.{/color}"
        centered "{color=#000000}The building collapses.{/color}"
        centered "{color=#000000}You knew it was coming.{/color}"
        centered "{color=#000000}What waits for you at the bottom?{/color}"
        centered "{color=#000000}At least you won't be alone.{/color}"
        $ end2 = True
        pause 2.0
        call credits from _call_credits
        jump credits
    else:
        play music "audio/end1-1.wav"
        centered "{color=#000000}This is the end.{/color}"
        centered "{color=#000000}The building collapses.{/color}"
        centered "{color=#000000}You didn't even know it was coming.{/color}"
        centered "{color=#000000}What waits for you at the bottom?{/color}"
        centered "{color=#000000}You are alone.{/color}"
        $ end3 = True
        pause 2.0
        call credits from _call_credits_1
        jump credits

label end1:
    centered "{color=#000000}This is the end.{/color}"
    centered "{color=#000000}You walk outside.{/color}"
    centered "{color=#000000}Everything is burning.{/color}"
    centered "{color=#000000}You feel the ground shake.{/color}"
    centered "{color=#000000}The sky is grey with smoke.{/color}"
    centered "{color=#000000}You never thought there would be a day like this.{/color}"
    centered "{color=#000000}You can't do anything now.{/color}"
    centered "{color=#000000}You are alone.{/color}"
    $ end1 = True
    pause 2.0
    call credits from _call_credits_2
    jump credits

label tunnel:
    scene bg tunnel1 with Dissolve(0.5)
    "You walk through the hole in the wall."
    "The tunnel is dark and narrow."
    "You can barely see anything."
    menu:
        "Keep walking.":
            scene bg tunnel2 with Dissolve(0.5)
            "You keep walking through the tunnel."
            stop music fadeout 2
            "You see a faint light."
            menu:
                "Keep walking.":
                    show phage with Dissolve(1)
                    play music "audio/scary1.mp3"
                    qu "Welcome."
                    qu "I have waited for you."
                    qu "How long have you been waiting?"
                    qu "A long time."
                    qu "One word answer."
                    qu "What can go around the world but stay in a corner?"
                    $ user_input = renpy.input("Answer:")
                    $ user_input = user_input.strip().upper()
                    if user_input == "STAMP":
                        qu "Yes."
                        jump q2
                    elif user_input == "POSTAGE":
                        qu "Yes."
                        jump q2
                    elif user_input == "POSTMARK":
                        qu "Yes."
                        jump q2
                    else:
                        qu "Incorrect."
                        qu "What a shame."
                        qu "Goodbye."
                        pause 1.0
                        $ renpy.quit()
                    label q2:
                    qu "One word answer."
                    qu "Where can you finish a book without finishing a sentence?"
                    $ user_input = renpy.input("Answer:")
                    $ user_input = user_input.strip().upper()
                    if user_input == "PRISON":
                        qu "Yes."
                        jump q3
                    elif user_input == "JAIL":
                        qu "Yes."
                        jump q3
                    elif user_input == "PENITENTIARY":
                        qu "Yes."
                        jump q3
                    else:
                        qu "Incorrect."
                        qu "What a shame."
                        qu "Goodbye."
                        pause 1.0
                        $ renpy.quit()

                    label q3:                    
                    qu "One word answer."
                    qu "What goes up a chimney down, but not down a chimney up?"
                    $ user_input = renpy.input("Answer:")
                    $ user_input = user_input.strip().upper()
                    if user_input == "UMBRELLA":
                        qu "Yes."
                        jump q4
                    elif user_input == "PARASOL":
                        qu "Yes."
                        jump q4
                    elif user_input == "BROLLY":
                        qu "Yes."
                        jump q4
                    else:
                        qu "Incorrect."
                        qu "What a shame."
                        qu "Goodbye."
                        pause 1.0
                        $ renpy.quit()

                    label q4:
                    qu "One word answer."
                    qu "An electric train is traveling south at 100 mph. The wind is blowing from the west at 20 mph. Which way does the smoke blow?"
                    $ user_input = renpy.input("Answer:")
                    $ user_input = user_input.strip().upper()
                    if user_input == "PHAGE":
                        if paper:     
                            show phage2
                            pause 3.0
                            stop music fadeout 2.0
                            qu "{cps=10}We will all miss the earth.{/cps}"
                            qu "{cps=10}All but me.{/cps}"
                            qu "{cps=10}I'll be gone.{/cps}"
                            qu "{cps=10}And then you.{/cps}"
                            qu "{cps=10}Goodbye.{/cps}"
                            stop music fadeout 2.0
                            scene bg white with Dissolve(3)
                            $ end4 = True
                            play music "audio/end1-1.wav"
                            call credits from _call_credits_3
                            jump credits
                        else:
                            qu "Incorrect."
                            qu "You have not pleased the masses."
                            qu "Goodbye."
                            pause 1.0
                            $ renpy.quit()
                    else:
                        qu "Incorrect."
                        qu "What a shame."
                        qu "Goodbye."
                        pause 1.0
                        $ renpy.quit()


                    
                "Turn around and go back.":
                    jump day6
        "Turn around and go back.":
            jump day6

label credits:
    $ credits_speed = 25 
    scene bg white 
    with dissolve
    show theend:
        yanchor 0.5 ypos 0.5
        xanchor 0.5 xpos 0.5
    with dissolve
    with Pause(1.0)
    hide theend 
    with dissolve
    show cred at Move((0.5, 2.5), (0.5, 0.0), credits_speed, repeat=False, bounce=False, xanchor="center", yanchor="bottom")
    with Pause(credits_speed)
    pause 1.0
    

    show ending_text:
        yanchor 0.5 ypos 0.5
        xanchor 0.5 xpos 0.5
    with dissolve
    with Pause(3)
    hide ending_text
    with dissolve

    show thanks:
        yanchor 0.5 ypos 0.5
        xanchor 0.5 xpos 0.5
    with dissolve
    with Pause(3)
    hide thanks
    with dissolve
    
    stop music fadeout 2.0
    pause 3.0
    $ renpy.quit()

init python:
    credits = ('Backgrounds', 'Jude Felstead'), ('Sprites and CG', 'Jude Felstead'), ('GUI', 'Jude Felstead'), ('Writing', 'Jude Felstead'), ('Programming', 'Jude Felstead'), ('Music', 'Jude Felstead'),
    credits_s = "{size=80}Credits\n\n"
    c1 = ''
    for c in credits:
        if not c1==c[0]:
            credits_s += "\n{size=40}{color=#000000}" + c[0] + "\n"
        credits_s += "{size=60}{color=#000000}" + c[1] + "\n"
        c1=c[0]
    

    def get_ending_text():
        if end1:
            return "{color=#000000}{size=60}Ending 1/4"
        elif end2:
            return "{color=#000000}{size=60}Ending 2/4"
        elif end3:
            return "{color=#000000}{size=60}Ending 3/4"
        elif end4:
            return "{color=#000000}{size=60}Ending 4/4"
        else:
            return "{color=#000000}{size=60}How did you get here?"
    
init:

    $ end1 = False
    $ end2 = False
    $ end3 = False
    $ end4 = False
    
    image cred = Text(credits_s, text_align=0.5)
    image theend = Text("{color=#000000}{size=80}The End", text_align=0.5)
    image thanks = Text("{color=#000000}{size=80}Sylus Reyndar", text_align=0.5)
    image ending_text = DynamicDisplayable(lambda st, at: (Text(get_ending_text(), text_align=0.5), None))


init:

    python:
    
        import math

        class Shaker(object):
        
            anchors = {
                'top' : 0.0,
                'center' : 0.5,
                'bottom' : 1.0,
                'left' : 0.0,
                'right' : 1.0,
                }
        
            def __init__(self, start, child, dist):
                if start is None:
                    start = child.get_placement()
                #
                self.start = [ self.anchors.get(i, i) for i in start ]  
                self.dist = dist   
                self.child = child
                
            def __call__(self, t, sizes):
               
                 
                def fti(x, r):
                    if x is None:
                        x = 0
                    if isinstance(x, float):
                        return int(x * r)
                    else:
                        return x

                xpos, ypos, xanchor, yanchor = [ fti(a, b) for a, b in zip(self.start, sizes) ]

                xpos = xpos - xanchor
                ypos = ypos - yanchor
                
                nx = xpos + (1.0-t) * self.dist * (renpy.random.random()*2-1)
                ny = ypos + (1.0-t) * self.dist * (renpy.random.random()*2-1)

                return (int(nx), int(ny), 0, 0)
        
        def _Shake(start, time, child=None, dist=100.0, **properties):

            move = Shaker(start, child, dist=dist)
        
            return renpy.display.layout.Motion(move, time, child, add_sizes=True, **properties)

        Shake = renpy.curry(_Shake)
    #

#
