﻿# TODO: Translation updated at 2026-05-23 18:55

translate english strings:

    # game/options.rpy:15
    old "Sylus Reyndar"
    new ""

