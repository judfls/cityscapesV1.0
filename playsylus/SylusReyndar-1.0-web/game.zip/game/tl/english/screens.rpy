﻿# TODO: Translation updated at 2026-05-23 18:55

translate english strings:

    # game/screens.rpy:249
    old "Back"
    new ""

    # game/screens.rpy:250
    old "History"
    new ""

    # game/screens.rpy:251
    old "Skip"
    new ""

    # game/screens.rpy:252
    old "Auto"
    new ""

    # game/screens.rpy:253
    old "Save"
    new ""

    # game/screens.rpy:254
    old "Q.Save"
    new ""

    # game/screens.rpy:255
    old "Q.Load"
    new ""

    # game/screens.rpy:256
    old "Prefs"
    new ""

    # game/screens.rpy:300
    old "Load"
    new ""

    # game/screens.rpy:301
    old "Preferences"
    new ""

    # game/screens.rpy:305
    old "Start"
    new ""

    # game/screens.rpy:319
    old "End Replay"
    new ""

    # game/screens.rpy:323
    old "Main Menu"
    new ""

    # game/screens.rpy:325
    old "About"
    new ""

    # game/screens.rpy:330
    old "Help"
    new ""

    # game/screens.rpy:336
    old "Quit"
    new ""

    # game/screens.rpy:521
    old "Return"
    new ""

    # game/screens.rpy:605
    old "Version [config.version!t]\n"
    new ""

    # game/screens.rpy:606
    old "Programmed by Jude Felstead\n"
    new ""

    # game/screens.rpy:607
    old "Story by Jude Felstead\n"
    new ""

    # game/screens.rpy:608
    old "Imagery by Jude Felstead\n"
    new ""

    # game/screens.rpy:609
    old "Music by Jude Felstead\n"
    new ""

    # game/screens.rpy:611
    old "Learn More"
    new ""

    # game/screens.rpy:653
    old "Page {}"
    new ""

    # game/screens.rpy:653
    old "Automatic saves"
    new ""

    # game/screens.rpy:653
    old "Quick saves"
    new ""

    # game/screens.rpy:695
    old "{#file_time}%A, %B %d %Y, %H:%M"
    new ""

    # game/screens.rpy:695
    old "empty slot"
    new ""

    # game/screens.rpy:715
    old "<"
    new ""

    # game/screens.rpy:719
    old "{#auto_page}A"
    new ""

    # game/screens.rpy:722
    old "{#quick_page}Q"
    new ""

    # game/screens.rpy:728
    old ">"
    new ""

    # game/screens.rpy:733
    old "Upload Sync"
    new ""

    # game/screens.rpy:737
    old "Download Sync"
    new ""

    # game/screens.rpy:797
    old "Display"
    new ""

    # game/screens.rpy:798
    old "Window"
    new ""

    # game/screens.rpy:799
    old "Fullscreen"
    new ""

    # game/screens.rpy:804
    old "Unseen Text"
    new ""

    # game/screens.rpy:805
    old "After Choices"
    new ""

    # game/screens.rpy:806
    old "Transitions"
    new ""

    # game/screens.rpy:819
    old "Text Speed"
    new ""

    # game/screens.rpy:823
    old "Auto-Forward Time"
    new ""

    # game/screens.rpy:830
    old "Music Volume"
    new ""

    # game/screens.rpy:837
    old "Sound Volume"
    new ""

    # game/screens.rpy:843
    old "Test"
    new ""

    # game/screens.rpy:847
    old "Voice Volume"
    new ""

    # game/screens.rpy:858
    old "Mute All"
    new ""

    # game/screens.rpy:977
    old "The dialogue history is empty."
    new ""

    # game/screens.rpy:1045
    old "Keyboard"
    new ""

    # game/screens.rpy:1046
    old "Mouse"
    new ""

    # game/screens.rpy:1049
    old "Gamepad"
    new ""

    # game/screens.rpy:1062
    old "Enter"
    new ""

    # game/screens.rpy:1063
    old "Advances dialogue and activates the interface."
    new ""

    # game/screens.rpy:1066
    old "Space"
    new ""

    # game/screens.rpy:1067
    old "Advances dialogue without selecting choices."
    new ""

    # game/screens.rpy:1070
    old "Arrow Keys"
    new ""

    # game/screens.rpy:1071
    old "Navigate the interface."
    new ""

    # game/screens.rpy:1074
    old "Escape"
    new ""

    # game/screens.rpy:1075
    old "Accesses the game menu."
    new ""

    # game/screens.rpy:1078
    old "Ctrl"
    new ""

    # game/screens.rpy:1079
    old "Skips dialogue while held down."
    new ""

    # game/screens.rpy:1082
    old "Tab"
    new ""

    # game/screens.rpy:1083
    old "Toggles dialogue skipping."
    new ""

    # game/screens.rpy:1086
    old "Page Up"
    new ""

    # game/screens.rpy:1087
    old "Rolls back to earlier dialogue."
    new ""

    # game/screens.rpy:1090
    old "Page Down"
    new ""

    # game/screens.rpy:1091
    old "Rolls forward to later dialogue."
    new ""

    # game/screens.rpy:1095
    old "Hides the user interface."
    new ""

    # game/screens.rpy:1099
    old "Takes a screenshot."
    new ""

    # game/screens.rpy:1103
    old "Toggles assistive {a=https://www.renpy.org/l/voicing}self-voicing{/a}."
    new ""

    # game/screens.rpy:1107
    old "Opens the accessibility menu."
    new ""

    # game/screens.rpy:1113
    old "Left Click"
    new ""

    # game/screens.rpy:1117
    old "Middle Click"
    new ""

    # game/screens.rpy:1121
    old "Right Click"
    new ""

    # game/screens.rpy:1125
    old "Mouse Wheel Up"
    new ""

    # game/screens.rpy:1129
    old "Mouse Wheel Down"
    new ""

    # game/screens.rpy:1136
    old "Right Trigger\nA/Bottom Button"
    new ""

    # game/screens.rpy:1140
    old "Left Trigger\nLeft Shoulder"
    new ""

    # game/screens.rpy:1144
    old "Right Shoulder"
    new ""

    # game/screens.rpy:1148
    old "D-Pad, Sticks"
    new ""

    # game/screens.rpy:1152
    old "Start, Guide, B/Right Button"
    new ""

    # game/screens.rpy:1156
    old "Y/Top Button"
    new ""

    # game/screens.rpy:1159
    old "Calibrate"
    new ""

    # game/screens.rpy:1224
    old "Yes"
    new ""

    # game/screens.rpy:1225
    old "No"
    new ""

    # game/screens.rpy:1271
    old "Skipping"
    new ""

    # game/screens.rpy:1585
    old "Menu"
    new ""

