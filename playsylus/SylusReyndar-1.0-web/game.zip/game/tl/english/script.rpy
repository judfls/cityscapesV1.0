﻿# TODO: Translation updated at 2026-05-23 18:55

# game/script.rpy:110
translate english start_9a2ddc8b:

    # "It's Tuesday."
    ""

# game/script.rpy:112
translate english start_0bea634d:

    # "You had a dream last night that you would like to forget for now."
    ""

# game/script.rpy:113
translate english start_532aaef4:

    # "You decide to turn the television on."
    ""

# game/script.rpy:115
translate english start_8ecfa8d2:

    # "The newscaster speaks to you."
    ""

# game/script.rpy:116
translate english start_f76051cd:

    # nc "Breaking news tonight: Scientists have detected unusual and widespread tectonic plate movement across the globe."
    nc ""

# game/script.rpy:117
translate english start_1224a620:

    # nc "Authorities are urging residents to remain vigilant for potential seismic activity throughout the day."
    nc ""

# game/script.rpy:118
translate english start_0f60ec5d:

    # nc "We'll have more on this story after your local forecast. I'm Matthew Nicholson, and this is Channel 9 News."
    nc ""

# game/script.rpy:120
translate english start_d396134a:

    # "You turn the TV off."
    ""

# game/script.rpy:121
translate english start_a20cefa7:

    # "..."
    ""

# game/script.rpy:123
translate english start_3ff9f9dc:

    # "You hear a knock from the door."
    ""

# game/script.rpy:125
translate english start_f2619a30:

    # "You look through the peep hole."
    ""

# game/script.rpy:127
translate english start_6d629f80:

    # nb "Hey, neighbour."
    nb ""

# game/script.rpy:128
translate english start_aee4b5e8:

    # nb "How are you doing in there?"
    nb ""

# game/script.rpy:131
translate english start_9057de96:

    # nb "Good."
    nb ""

# game/script.rpy:134
translate english start_10fa6f50:

    # nb "Well I'm not doing so hot either."
    nb ""

# game/script.rpy:139
translate english after_menu_6164effd:

    # nb "Have you heard about the earthquakes?"
    nb ""

# game/script.rpy:142
translate english after_menu_1ef2537f:

    # nb "Just wanted to check on you."
    nb ""

# game/script.rpy:143
translate english after_menu_75956db7:

    # nb "Keep in touch."
    nb ""

# game/script.rpy:146
translate english after_menu_38665ec8:

    # nb "Quite honestly, I have no idea."
    nb ""

# game/script.rpy:147
translate english after_menu_fe4cd103:

    # nb "I think we should just wait it out."
    nb ""

# game/script.rpy:152
translate english after_menu2_05699789:

    # nb "You can contact me at 780-444-543."
    nb ""

# game/script.rpy:153
translate english after_menu2_68e02c0c:

    # nb "See you around."
    nb ""

# game/script.rpy:155
translate english after_menu2_a20cefa7:

    # "..."
    ""

# game/script.rpy:157
translate english after_menu2_5a98b131:

    # "It's 12:00pm."
    ""

# game/script.rpy:163
translate english day1_899a7354:

    # "It's very boring."
    ""

# game/script.rpy:164
translate english day1_b34c6734:

    # "At least it's a good time killer."
    ""

# game/script.rpy:170
translate english day1_f4d85ae4:

    # nb "Who is this?"
    nb ""

# game/script.rpy:173
translate english day1_325fdc93:

    # nb "I think it's working great."
    nb ""

# game/script.rpy:174
translate english day1_a20cefa7:

    # "..."
    ""

# game/script.rpy:175
translate english day1_91f89f9c:

    # nb "Have a good rest of your day."
    nb ""

# game/script.rpy:178
translate english day1_1d074901:

    # nb "Don't scare me."
    nb ""

# game/script.rpy:181
translate english day1_70582648:

    # "Phone" "No lines availible currently."
    "Phone" ""

# game/script.rpy:186
translate english day1_62acd495:

    # "You cleaned up around the house."
    ""

# game/script.rpy:191
translate english day1_730e6aec:

    # "There's hot water and soap."
    ""

# game/script.rpy:192
translate english day1_0a00f088:

    # "You feel refreshed."
    ""

# game/script.rpy:197
translate english day1_d13185ec:

    # nc "A 5.2 magnitude earthquake has struck the central Pacific Ocean, one of several seismic events recorded globally. The quake has triggered multiple tsunamis, with coastal regions across Asia now on high alert."
    nc ""

# game/script.rpy:199
translate english day1_764426b8:

    # nc "Stay alert. This is Matthew Nicholson with Channel 9 News."
    nc ""

# game/script.rpy:208
translate english day1end_a65ee938:

    # "Don't let the bed bugs bite."
    ""

# game/script.rpy:214
translate english day2start_03e499be:

    # "It's Wednesday."
    ""

# game/script.rpy:216
translate english day2start_49fdd1c7:

    # "You had that same dream."
    ""

# game/script.rpy:221
translate english day2start_5025a46e:

    # "You woke up in your bed..."
    ""

# game/script.rpy:224
translate english day2start_e1a33c19:

    # "And heard a knock at the door."
    ""

# game/script.rpy:225
translate english day2start_5bd74ef9:

    # "You got up.."
    ""

# game/script.rpy:226
translate english day2start_224a4d73:

    # "And.."
    ""

# game/script.rpy:229
translate english day2start_76dbd12d:

    # "You forgot."
    ""

# game/script.rpy:238
translate english day2tv_532aaef4:

    # "You decide to turn the television on."
    ""

# game/script.rpy:240
translate english day2tv_060af964:

    # nc "Good morning. Officials are advising residents to stay home today as seismic activity in the region continues to increase."
    nc ""

# game/script.rpy:241
translate english day2tv_e6ca9159:

    # nc "A new report has revealed unusual pulses emanating from deep within the Earth. A phenomenon scientists are calling the \"Earth Heartbeat.\""
    nc ""

# game/script.rpy:242
translate english day2tv_833a0cad:

    # nc "Stay safe, remain vigilant, and please stay indoors. I'm Matthew Nicholson, and this is Channel 9 News."
    nc ""

# game/script.rpy:245
translate english day2tv_da163a56:

    # "You hear a knock at the door."
    ""

# game/script.rpy:247
translate english day2tv_f2619a30:

    # "You look through the peep hole."
    ""

# game/script.rpy:249
translate english day2tv_006fc7ff:

    # qu "Hello?"
    qu ""

# game/script.rpy:250
translate english day2tv_9fd3fe7f:

    # qu "Can I trust you?"
    qu ""

# game/script.rpy:253
translate english day2tv_ad18ebee:

    # qu "Thank you."
    qu ""

# game/script.rpy:255
translate english day2tv_624f079c:

    # qu "What makes me is not my choice."
    qu ""

# game/script.rpy:257
translate english day2tv_68963841:

    # qu "See the wreck within me."
    qu ""

# game/script.rpy:258
translate english day2tv_9f9961fa:

    # qu "My child, Phage is here."
    qu ""

# game/script.rpy:259
translate english day2tv_91d6f6c3:

    # qu "Destiny awaits."
    qu ""

# game/script.rpy:260
translate english day2tv_8958b989:

    # qu "Be careful."
    qu ""

# game/script.rpy:263
translate english day2tv_4680d472:

    # qu "Can't tell yet."
    qu ""

# game/script.rpy:264
translate english day2tv_61360854:

    # qu "You learn in due time."
    qu ""

# game/script.rpy:266
translate english day2tv_ec3df409:

    # qu "..."
    qu ""

# game/script.rpy:267
translate english day2tv_f4047e1a:

    # qu "I'll be back."
    qu ""

# game/script.rpy:269
translate english day2tv_a20cefa7:

    # "..."
    ""

# game/script.rpy:272
translate english day2tv_56eac2a4:

    # "Another knock comes from the door."
    ""

# game/script.rpy:274
translate english day2tv_aedc11be:

    # qu "Hey."
    qu ""

# game/script.rpy:275
translate english day2tv_a07ed61a:

    # qu "I saw that guy come over here."
    qu ""

# game/script.rpy:276
translate english day2tv_e21e7913:

    # qu "He's been disturbing people all around the apartment."
    qu ""

# game/script.rpy:277
translate english day2tv_8f43a1cc:

    # qu "My name's Arthur by the way."
    qu ""

# game/script.rpy:278
translate english day2tv_aee4d3e4:

    # ar "He says \"The Phage is coming, the Phage is coming\" like a broken fucking record."
    ar ""

# game/script.rpy:279
translate english day2tv_76ea07db:

    # ar "He says the first door he picks is the \"Desired one.\""
    ar ""

# game/script.rpy:280
translate english day2tv_add12885:

    # ar "Do what he says."
    ar ""

# game/script.rpy:282
translate english day2tv_a20cefa7_1:

    # "..."
    ""

# game/script.rpy:284
translate english day2tv_12e716a0:

    # "It's 2:00pm."
    ""

# game/script.rpy:289
translate english day2_899a7354:

    # "It's very boring."
    ""

# game/script.rpy:290
translate english day2_b34c6734:

    # "At least it's a good time killer."
    ""

# game/script.rpy:296
translate english day2_acb60a52:

    # nb "Hey neighbour. How's it treating you?"
    nb ""

# game/script.rpy:299
translate english day2_be90e01a:

    # nb "I think so."
    nb ""

# game/script.rpy:300
translate english day2_a20cefa7:

    # "..."
    ""

# game/script.rpy:301
translate english day2_12002253:

    # nb "Yeah... yeah, I saw him doing laundry once."
    nb ""

# game/script.rpy:302
translate english day2_a81ae615:

    # nb "Weird guy."
    nb ""

# game/script.rpy:305
translate english day2_ba64d110:

    # nb "No clue."
    nb ""

# game/script.rpy:308
translate english day2_70582648:

    # "Phone" "No lines availible currently."
    "Phone" ""

# game/script.rpy:314
translate english day2_880ef4ed:

    # "There's nothing to clean."
    ""

# game/script.rpy:319
translate english day2_730e6aec:

    # "There's hot water and soap."
    ""

# game/script.rpy:320
translate english day2_936a4a9f:

    # "Your pipes are creaking."
    ""

# game/script.rpy:325
translate english day2_643c0c1b:

    # "Weatherman" "A dangerous heat event is sweeping across the country, {cps=25}with temperatures reaching a severe 42° Celsius. {/cps} {cps=20}Health officials are urging residents, particularly the elderly and young children,{/cps} {cps=15}to avoid prolonged outdoor exposure, stay hydrated,{cps=10} and seek air-conditioned{/cps} {cps=5}shelter where possible.{/cps}"
    "Weatherman" ""

# game/script.rpy:330
translate english day2_74fd1e7c:

    # "Weatherman" "{cps=5}Death is a low yet juicy fruit. Decide your fate from the tree. The branches tell you. You. I know you. You are... needed.{/cps}"
    "Weatherman" ""

# game/script.rpy:341
translate english day2end_b99d8349:

    # "Sleep tight."
    ""

# game/script.rpy:347
translate english day3start_9d7104f8:

    # "It's Thursday."
    ""

# game/script.rpy:349
translate english day3start_49fdd1c7:

    # "You had that same dream."
    ""

# game/script.rpy:354
translate english day3start_5025a46e:

    # "You woke up in your bed..."
    ""

# game/script.rpy:357
translate english day3start_e1a33c19:

    # "And heard a knock at the door."
    ""

# game/script.rpy:358
translate english day3start_5bd74ef9:

    # "You got up.."
    ""

# game/script.rpy:359
translate english day3start_224a4d73:

    # "And.."
    ""

# game/script.rpy:360
translate english day3start_49749261:

    # "Opened the door.."
    ""

# game/script.rpy:362
translate english day3start_9d97ded5:

    # "But.."
    ""

# game/script.rpy:365
translate english day3start_76dbd12d:

    # "You forgot."
    ""

# game/script.rpy:371
translate english day3start_6f7d21e0:

    # "It's better that way."
    ""

# game/script.rpy:375
translate english day3tv_532aaef4:

    # "You decide to turn the television on."
    ""

# game/script.rpy:377
translate english day3tv_8d2496f2:

    # nc "Authorities are issuing an urgent message to all residents at this time: please remain calm and stay indoors until further notice."
    nc ""

# game/script.rpy:378
translate english day3tv_f563c397:

    # nc "Officials are strongly advising the public to avoid any and all outdoor activity, as conditions outside remain extremely dangerous."
    nc ""

# game/script.rpy:379
translate english day3tv_e511ee16:

    # nc "Do not attempt to leave your home, and under no circumstances should you allow unfamiliar individuals to enter your residence."
    nc ""

# game/script.rpy:381
translate english day3tv_975280ef:

    # nc "Lock your doors and keep your windows shut. Emergency personnel are actively working to address the situation, and updates will be provided as more information becomes available."
    nc ""

# game/script.rpy:382
translate english day3tv_619afb1b:

    # nc "We urge everyone to remain patient, stay vigilant, and above all... stay safe. We will continue to bring you live coverage of this developing story as it unfolds."
    nc ""

# game/script.rpy:383
translate english day3tv_a3de02b4:

    # nc "I'm Matthew Nicholson, and this is Channel 9 News."
    nc ""

# game/script.rpy:386
translate english day3tv_da163a56:

    # "You hear a knock at the door."
    ""

# game/script.rpy:388
translate english day3tv_f2619a30:

    # "You look through the peep hole."
    ""

# game/script.rpy:390
translate english day3tv_af173b07:

    # hm "So I see you again."
    hm ""

# game/script.rpy:391
translate english day3tv_3fb68697:

    # hm "You need to help me."
    hm ""

# game/script.rpy:394
translate english day3tv_8c3d751d:

    # hm "Good."
    hm ""

# game/script.rpy:395
translate english day3tv_191bb5b0:

    # hm "A man will come to your door today."
    hm ""

# game/script.rpy:396
translate english day3tv_4dc15775:

    # hm "Do not let him in."
    hm ""

# game/script.rpy:400
translate english day3tv_5579a44f:

    # hm "You've killed us."
    hm ""

# game/script.rpy:401
translate english day3tv_4e84f5a6:

    # hm "Goodbye."
    hm ""

# game/script.rpy:403
translate english day3tv_a20cefa7:

    # "..."
    ""

# game/script.rpy:406
translate english day3tv_56eac2a4:

    # "Another knock comes from the door."
    ""

# game/script.rpy:408
translate english day3tv_b08e129e:

    # "Policeman" "This is the police. Open the door."
    "Policeman" ""

# game/script.rpy:409
translate english day3tv_a20cefa7_1:

    # "..."
    ""

# game/script.rpy:410
translate english day3tv_a85d6461:

    # "Policeman" "Open up."
    "Policeman" ""

# game/script.rpy:421
translate english day3tv_07a17190:

    # "Policeman" "Open the fucking door."
    "Policeman" ""

# game/script.rpy:423
translate english day3tv_847c3aae:

    # "Policeman" "Please."
    "Policeman" ""

# game/script.rpy:437
translate english day3tv_a20cefa7_2:

    # "..."
    ""

# game/script.rpy:440
translate english day3tv_56eac2a4_1:

    # "Another knock comes from the door."
    ""

# game/script.rpy:442
translate english day3tv_d024f0d9:

    # ar "You got any sugar?"
    ar ""

# game/script.rpy:446
translate english sugaripod_639f81a3:

    # ar "Ok."
    ar ""

# game/script.rpy:449
translate english sugaripod_c100fd1f:

    # ar "Thank you."
    ar ""

# game/script.rpy:452
translate english sugaripod_fad5ac72:

    # ar "Whatever."
    ar ""

# game/script.rpy:456
translate english sugaripod_dc59c728:

    # "It's 3:00pm"
    ""

# game/script.rpy:462
translate english day3_cb726f27:

    # "It's very fun, actually."
    ""

# game/script.rpy:463
translate english day3_a607b72b:

    # "And it's a good time killer."
    ""

# game/script.rpy:469
translate english day3_3b2f66b2:

    # nb "Hey neighbour. What's going on?"
    nb ""

# game/script.rpy:472
translate english day3_20f8f0e6:

    # nb "Hold on. Someone is at my door."
    nb ""

# game/script.rpy:479
translate english day3_70582648:

    # "Phone" "No lines availible currently."
    "Phone" ""

# game/script.rpy:485
translate english day3_046ae155:

    # "You find a small hole in your wall."
    ""

# game/script.rpy:489
translate english day3_5285390f:

    # "It's too dark to see anything."
    ""

# game/script.rpy:497
translate english day3_d51a0ace:

    # "There's hot water but barely any soap."
    ""

# game/script.rpy:498
translate english day3_afbda014:

    # "Your pipes are still creaking."
    ""

# game/script.rpy:513
translate english day3end_625b7d56:

    # "Time to hit the hay."
    ""

# game/script.rpy:519
translate english day4start_b78b30fe:

    # "It's Friday."
    ""

# game/script.rpy:521
translate english day4start_49fdd1c7:

    # "You had that same dream."
    ""

# game/script.rpy:526
translate english day4start_5025a46e:

    # "You woke up in your bed..."
    ""

# game/script.rpy:529
translate english day4start_e1a33c19:

    # "And heard a knock at the door."
    ""

# game/script.rpy:530
translate english day4start_6b98fc9b:

    # "You got up and opened the door."
    ""

# game/script.rpy:532
translate english day4start_bf0874e3:

    # "But..."
    ""

# game/script.rpy:533
translate english day4start_57c72150:

    # "No one was there."
    ""

# game/script.rpy:534
translate english day4start_f890bed4:

    # "You.."
    ""

# game/script.rpy:535
translate english day4start_ab3261b1:

    # "Walked."
    ""

# game/script.rpy:536
translate english day4start_705e9f98:

    # "To the.."
    ""

# game/script.rpy:539
translate english day4start_76dbd12d:

    # "You forgot."
    ""

# game/script.rpy:545
translate english day4start_6f7d21e0:

    # "It's better that way."
    ""

# game/script.rpy:549
translate english day4tv_532aaef4:

    # "You decide to turn the television on."
    ""

# game/script.rpy:553
translate english day4tv_da163a56:

    # "You hear a knock at the door."
    ""

# game/script.rpy:555
translate english day4tv_f2619a30:

    # "You look through the peep hole."
    ""

# game/script.rpy:557
translate english day4tv_73717fff:

    # ar "Did you hear what happened to Colin?"
    ar ""

# game/script.rpy:560
translate english day4tv_1fa4e5b6:

    # ar "Your next door neighbour."
    ar ""

# game/script.rpy:561
translate english day4tv_c95d9337:

    # ar "He was found dead."
    ar ""

# game/script.rpy:564
translate english day4tv_c95d9337_1:

    # ar "He was found dead."
    ar ""

# game/script.rpy:565
translate english day4tv_914577a9:

    # ar "They say it was that \"Policeman\" who came into the building yesterday."
    ar ""

# game/script.rpy:566
translate english day4tv_978f89a6:

    # ar "Thank God I turned him away."
    ar ""

# game/script.rpy:567
translate english day4tv_c77e79e1:

    # ar "I guess you did too."
    ar ""

# game/script.rpy:568
translate english day4tv_91d88482:

    # ar "Be careful."
    ar ""

# game/script.rpy:569
translate english day4tv_56a6429a:

    # ar "Things are getting pretty crazy out here."
    ar ""

# game/script.rpy:570
translate english day4tv_a8384d8f:

    # ar "Here. Have my number. It's 825-293-182."
    ar ""

# game/script.rpy:572
translate english day4tv_a20cefa7:

    # "..."
    ""

# game/script.rpy:575
translate english day4tv_56eac2a4:

    # "Another knock comes from the door."
    ""

# game/script.rpy:577
translate english day4tv_70e39a7f:

    # qu "{cps=10}Life is the harbinger of death.{/cps}"
    qu ""

# game/script.rpy:578
translate english day4tv_86c5fb8a:

    # qu "{cps=10}Remember.{/cps}"
    qu ""

# game/script.rpy:579
translate english day4tv_3045c2cb:

    # qu "{cps=10}Do not overstay your welcome.{/cps}"
    qu ""

# game/script.rpy:580
translate english day4tv_a15bb5c2:

    # qu "{cps=10}You'll be dead soon anyway.{/cps}"
    qu ""

# game/script.rpy:581
translate english day4tv_c1c2f3b2:

    # qu "{cps=10}The end is a beginning.{/cps}"
    qu ""

# game/script.rpy:583
translate english day4tv_a20cefa7_1:

    # "..."
    ""

# game/script.rpy:586
translate english day4tv_56eac2a4_1:

    # "Another knock comes from the door."
    ""

# game/script.rpy:588
translate english day4tv_4a461a0a:

    # hm "I need more help."
    hm ""

# game/script.rpy:591
translate english day4tv_8c3d751d:

    # hm "Good."
    hm ""

# game/script.rpy:592
translate english day4tv_e10ab556:

    # hm "Take your opertunity on day six."
    hm ""

# game/script.rpy:593
translate english day4tv_1e43e6e4:

    # hm "Do not be frightened by what you see."
    hm ""

# game/script.rpy:594
translate english day4tv_deab72f3:

    # hm "You'll need this."
    hm ""

# game/script.rpy:597
translate english day4tv_588efe03:

    # hm "Don't get forgetful now."
    hm ""

# game/script.rpy:601
translate english day4tv_487bc9d6:

    # hm "..."
    hm ""

# game/script.rpy:604
translate english day4tv_5579a44f:

    # hm "You've killed us."
    hm ""

# game/script.rpy:605
translate english day4tv_4e84f5a6:

    # hm "Goodbye."
    hm ""

# game/script.rpy:607
translate english day4tv_2a978c61:

    # "You're halfway through your food supply."
    ""

# game/script.rpy:608
translate english day4tv_12e716a0:

    # "It's 2:00pm."
    ""

# game/script.rpy:614
translate english day4_2dc3c5ad:

    # "Your aunt gave you these."
    ""

# game/script.rpy:616
translate english day4_85def789:

    # "They remind you of better times."
    ""

# game/script.rpy:622
translate english day4_b8798de8:

    # ar "Hello?"
    ar ""

# game/script.rpy:623
translate english day4_a01cf96c:

    # "Muffled noises of china breaking come from the telephone."
    ""

# game/script.rpy:624
translate english day4_08fa7f12:

    # ar "Oh well.."
    ar ""

# game/script.rpy:628
translate english day4_0e17a7cc:

    # ni "911, What's your emergency?"
    ni ""

# game/script.rpy:631
translate english day4_28c0a3c6:

    # "Beep."
    ""

# game/script.rpy:634
translate english day4_28c0a3c6_1:

    # "Beep."
    ""

# game/script.rpy:641
translate english day4_570b3f2e:

    # "You look at the hole in your wall again."
    ""

# game/script.rpy:642
translate english day4_25924d9f:

    # "It seems to have gotten bigger."
    ""

# game/script.rpy:646
translate english day4_5285390f:

    # "It's too dark to see anything."
    ""

# game/script.rpy:648
translate english day4_7c053804:

    # "You could use your flashlight to see better."
    ""

# game/script.rpy:651
translate english day4_1783850e:

    # "The hole tunnels into the wall and goes on for a while."
    ""

# game/script.rpy:660
translate english day4_686c4c72:

    # "No more soap."
    ""

# game/script.rpy:675
translate english day4end_f7465c02:

    # "Welp, the sheep ain't gonna count themselves."
    ""

# game/script.rpy:681
translate english day5start_80a2524d:

    # "It's Saturday."
    ""

# game/script.rpy:683
translate english day5start_49fdd1c7:

    # "You had that same dream."
    ""

# game/script.rpy:688
translate english day5start_5025a46e:

    # "You woke up in your bed..."
    ""

# game/script.rpy:691
translate english day5start_e1a33c19:

    # "And heard a knock at the door."
    ""

# game/script.rpy:692
translate english day5start_6b98fc9b:

    # "You got up and opened the door."
    ""

# game/script.rpy:694
translate english day5start_42574701:

    # "But no one was there."
    ""

# game/script.rpy:695
translate english day5start_0948866d:

    # "You walked."
    ""

# game/script.rpy:696
translate english day5start_705e9f98:

    # "To the.."
    ""

# game/script.rpy:697
translate english day5start_8a6a0882:

    # "Stairs."
    ""

# game/script.rpy:699
translate english day5start_379bfcd0:

    # "You walked down the stairs."
    ""

# game/script.rpy:701
translate english day5start_224a4d73:

    # "And.."
    ""

# game/script.rpy:702
translate english day5start_493c09b1:

    # "Wait.."
    ""

# game/script.rpy:705
translate english day5start_76dbd12d:

    # "You forgot."
    ""

# game/script.rpy:711
translate english day5start_6f7d21e0:

    # "It's better that way."
    ""

# game/script.rpy:715
translate english day5tv_532aaef4:

    # "You decide to turn the television on."
    ""

# game/script.rpy:719
translate english day5tv_da163a56:

    # "You hear a knock at the door."
    ""

# game/script.rpy:721
translate english day5tv_f2619a30:

    # "You look through the peep hole."
    ""

# game/script.rpy:723
translate english day5tv_c5610466:

    # qu "Hey kid, I've been trekking around for a while now, trying to find a place to stay."
    qu ""

# game/script.rpy:724
translate english day5tv_81440fc6:

    # qu "I don't have much, but I can share with you if you let me in."
    qu ""

# game/script.rpy:726
translate english day5tv_4bb18dd4:

    # qu "My name's Seb, by the way."
    qu ""

# game/script.rpy:730
translate english day5seb_9fe67586:

    # sb "Thank you, I really appreciate it."
    sb ""

# game/script.rpy:731
translate english day5seb_a4bde810:

    # sb "I sure hope you aren't one of the insane ones out here."
    sb ""

# game/script.rpy:736
translate english day5seb_161ca094:

    # sb "I've got some clothes, soap, a shovel, a sleeping bag, and food."
    sb ""

# game/script.rpy:740
translate english day5seb_db77b3a8:

    # sb "Oh, alright. I understand."
    sb ""

# game/script.rpy:742
translate english day5seb_a20cefa7:

    # "..."
    ""

# game/script.rpy:745
translate english day5seb_56eac2a4:

    # "Another knock comes from the door."
    ""

# game/script.rpy:747
translate english day5seb_7a0ca2c2:

    # hm "One more thing."
    hm ""

# game/script.rpy:750
translate english day5seb_8c3d751d:

    # hm "Good."
    hm ""

# game/script.rpy:751
translate english day5seb_2bf302a7:

    # hm "A show of trust."
    hm ""

# game/script.rpy:752
translate english day5seb_c78e3fc0:

    # hm "I will enter and kill you right now, or I won't."
    hm ""

# game/script.rpy:753
translate english day5seb_d86627dc:

    # hm "Your choice."
    hm ""

# game/script.rpy:759
translate english day5seb_b2a1fb82:

    # "He doesn't enter."
    ""

# game/script.rpy:761
translate english day5seb_594b6a8c:

    # "He just stands there."
    ""

# game/script.rpy:764
translate english day5seb_1e5a76ff:

    # hm "See?"
    hm ""

# game/script.rpy:765
translate english day5seb_c7b05f40:

    # hm "I'll be back tomorrow."
    hm ""

# game/script.rpy:769
translate english day5seb_df0aa81d:

    # hm "Very well"
    hm ""

# game/script.rpy:772
translate english day5seb_156a04ec:

    # hm "Your salvation lost."
    hm ""

# game/script.rpy:773
translate english day5seb_4e84f5a6:

    # hm "Goodbye."
    hm ""

# game/script.rpy:778
translate english day5seb_c4394c6d:

    # "You're running out of food."
    ""

# game/script.rpy:779
translate english day5seb_f72d2d9c:

    # "It's 1:00pm."
    ""

# game/script.rpy:789
translate english day5_469071a5:

    # "You play Dots and Boxes with Seb."
    ""

# game/script.rpy:790
translate english day5_791219e6:

    # "He's pretty good at it."
    ""

# game/script.rpy:792
translate english day5_9581b9a9:

    # "You play Dots and Boxes by yourself."
    ""

# game/script.rpy:793
translate english day5_3da456bf:

    # "It's boring."
    ""

# game/script.rpy:799
translate english day5_c209724f:

    # ar "Hey. How's it going?"
    ar ""

# game/script.rpy:802
translate english day5_bc66c1e5:

    # ar "Alright, make sure he doesn't cause any trouble."
    ar ""

# game/script.rpy:803
translate english day5_c1bbeb11:

    # ar "I might have to file a noise complaint."
    ar ""

# game/script.rpy:804
translate english day5_ff3a6de2:

    # ar "Only joking."
    ar ""

# game/script.rpy:807
translate english day5_a796d358:

    # ar "He just knocked on my door and asked to come in."
    ar ""

# game/script.rpy:808
translate english day5_f16b3a28:

    # ar "I let him in."
    ar ""

# game/script.rpy:809
translate english day5_a8f23997:

    # ar "Nice guy."
    ar ""

# game/script.rpy:810
translate english day5_2d97a288:

    # ar "Really bad at Hangman though."
    ar ""

# game/script.rpy:811
translate english day5_a5d2bb00:

    # ar "Who guesses \"J\" first?"
    ar ""

# game/script.rpy:816
translate english day5_70582648:

    # "Phone" "No lines availible currently."
    "Phone" ""

# game/script.rpy:822
translate english day5_570b3f2e:

    # "You look at the hole in your wall again."
    ""

# game/script.rpy:823
translate english day5_d4f14878:

    # "It seems to have gotten even bigger."
    ""

# game/script.rpy:826
translate english day5_aa534da7:

    # sb "What the hell is that?"
    sb ""

# game/script.rpy:828
translate english day5_a20cefa7:

    # "..."
    ""

# game/script.rpy:831
translate english day5_5285390f:

    # "It's too dark to see anything."
    ""

# game/script.rpy:833
translate english day5_7c053804:

    # "You could use your flashlight to see better."
    ""

# game/script.rpy:836
translate english day5_1783850e:

    # "The hole tunnels into the wall and goes on for a while."
    ""

# game/script.rpy:837
translate english day5_0d2a6f12:

    # "You hear a distant murmuring coming from the hole."
    ""

# game/script.rpy:847
translate english day5_1955e41e:

    # "You use Seb's soap."
    ""

# game/script.rpy:848
translate english day5_f53d6be2:

    # "He also fixed the heater for you."
    ""

# game/script.rpy:849
translate english day5_576f5d5d:

    # "Nice guy."
    ""

# game/script.rpy:852
translate english day5_d3e9cc77:

    # "The water's cold now."
    ""

# game/script.rpy:853
translate english day5_19c3c8ca:

    # "Also you're out of soap."
    ""

# game/script.rpy:859
translate english day5_3525b6cf:

    # "Seb fixes the TV for you."
    ""

# game/script.rpy:860
translate english day5_e14d52cf:

    # "You and Seb watch TV together."
    ""

# game/script.rpy:861
translate english day5_a277e0a2:

    # "It's nice to have some company."
    ""

# game/script.rpy:862
translate english day5_73771c32:

    # nc "We're getting reports of a new seismic event, with an estimated magnitude of 6.8. The epicenter is located near the city of San Francisco, and residents are being urged to take immediate precautions."
    nc ""

# game/script.rpy:863
translate english day5_23bccfba:

    # sb "Can we turn this off? I don't want to hear about it."
    sb ""

# game/script.rpy:878
translate english day5end_1ef7b3d1:

    # "It's Bedtime for Bonzo."
    ""

# game/script.rpy:884
translate english day6start_b901b8f1:

    # "It's Sunday."
    ""

# game/script.rpy:886
translate english day6start_49fdd1c7:

    # "You had that same dream."
    ""

# game/script.rpy:891
translate english day6start_5025a46e:

    # "You woke up in your bed..."
    ""

# game/script.rpy:894
translate english day6start_e1a33c19:

    # "And heard a knock at the door."
    ""

# game/script.rpy:895
translate english day6start_31de0ffa:

    # "You got up and.."
    ""

# game/script.rpy:896
translate english day6start_49749261:

    # "Opened the door.."
    ""

# game/script.rpy:898
translate english day6start_42574701:

    # "But no one was there."
    ""

# game/script.rpy:899
translate english day6start_2690b1b3:

    # "You walked to the stairs"
    ""

# game/script.rpy:900
translate english day6start_8a6a0882:

    # "Stairs."
    ""

# game/script.rpy:902
translate english day6start_379bfcd0:

    # "You walked down the stairs."
    ""

# game/script.rpy:905
translate english day6start_224a4d73:

    # "And.."
    ""

# game/script.rpy:916
translate english day6start_6f7d21e0:

    # "It's better that way."
    ""

# game/script.rpy:920
translate english day6start_493c09b1:

    # "Wait.."
    ""

# game/script.rpy:921
translate english day6start_98ad80ac:

    # "You should have remembered more."
    ""

# game/script.rpy:924
translate english day6start_76dbd12d:

    # "You forgot."
    ""

# game/script.rpy:929
translate english day6start_6f7d21e0_1:

    # "It's better that way."
    ""

# game/script.rpy:933
translate english day6tv_532aaef4:

    # "You decide to turn the television on."
    ""

# game/script.rpy:936
translate english day6tv_61a80643:

    # nc "Death toll rises to 500 after devastating earthquake strikes downtown area. Rescue efforts continue as authorities work tirelessly to provide aid and support to those affected by the disaster."
    nc ""

# game/script.rpy:937
translate english day6tv_cd14f2c3:

    # sb "C'mon man, can we change the channel?"
    sb ""

# game/script.rpy:938
translate english day6tv_b8db76c2:

    # sb "It's too depressing."
    sb ""

# game/script.rpy:943
translate english day6tv_da163a56:

    # "You hear a knock at the door."
    ""

# game/script.rpy:945
translate english day6tv_d34ad028:

    # "You look through the peep hole"
    ""

# game/script.rpy:948
translate english day6tv_b55d0ca4:

    # hm "You've been good to me."
    hm ""

# game/script.rpy:949
translate english day6tv_52b63661:

    # hm "I don't have much left to give you, but you'll need this."
    hm ""

# game/script.rpy:952
translate english day6tv_f5a25f49:

    # hm "I know where your headed."
    hm ""

# game/script.rpy:953
translate english day6tv_29178708:

    # hm "Use this to find your way."
    hm ""

# game/script.rpy:954
translate english day6tv_2c18ceae:

    # "The paper has numbers written on it."
    ""

# game/script.rpy:955
translate english day6tv_15372441:

    # "It looks like a phone number."
    ""

# game/script.rpy:959
translate english day6tv_0fc0f957:

    # hm "Shame."
    hm ""

# game/script.rpy:961
translate english day6tv_cf6f4ff1:

    # hm "You haven't done enough for me yet."
    hm ""

# game/script.rpy:962
translate english day6tv_9e8245ef:

    # hm "You don't trust me enough."
    hm ""

# game/script.rpy:963
translate english day6tv_4e84f5a6:

    # hm "Goodbye."
    hm ""

# game/script.rpy:964
translate english day6tv_a6e1ffba:

    # hm "Enjoy your last days."
    hm ""

# game/script.rpy:966
translate english day6tv_a20cefa7:

    # "..."
    ""

# game/script.rpy:971
translate english day6tv_63239e9a:

    # "You're almost completely out of food."
    ""

# game/script.rpy:972
translate english day6tv_94e9feeb:

    # "You might have enough for one more day."
    ""

# game/script.rpy:973
translate english day6tv_5a98b131:

    # "It's 12:00pm."
    ""

# game/script.rpy:983
translate english day6_98a738d4:

    # "You play Hangman with Seb."
    ""

# game/script.rpy:984
translate english day6_3a263791:

    # "He's pretty bad at it."
    ""

# game/script.rpy:985
translate english day6_1c84daf8:

    # "Who guesses \"W\" first?"
    ""

# game/script.rpy:987
translate english day6_c37f4fa9:

    # "You play Hangman by yourself."
    ""

# game/script.rpy:988
translate english day6_8190e61d:

    # "It's really easy."
    ""

# game/script.rpy:994
translate english day6_eac10ed8:

    # ar "Hey, whats up?"
    ar ""

# game/script.rpy:997
translate english day6_bf40081a:

    # ar "There's nothing better to do."
    ar ""

# game/script.rpy:1002
translate english day6_995dbfde:

    # "You call the number on the paper."
    ""

# game/script.rpy:1003
translate english day6_ae73fb23:

    # "It rings a few times before someone picks up."
    ""

# game/script.rpy:1004
translate english day6_006fc7ff:

    # qu "Hello?"
    qu ""

# game/script.rpy:1005
translate english day6_0bf5c4e8:

    # qu "The last riddle he speaks has no answer."
    qu ""

# game/script.rpy:1006
translate english day6_6f0d217f:

    # qu "You must say Phage."
    qu ""

# game/script.rpy:1007
translate english day6_b3e0fdab:

    # "The line goes dead."
    ""

# game/script.rpy:1011
translate english day6_70582648:

    # "Phone" "No lines availible currently."
    "Phone" ""

# game/script.rpy:1017
translate english day6_570b3f2e:

    # "You look at the hole in your wall again."
    ""

# game/script.rpy:1018
translate english day6_d4f14878:

    # "It seems to have gotten even bigger."
    ""

# game/script.rpy:1020
translate english day6_f718fc2d:

    # "It's big enough to fit through."
    ""

# game/script.rpy:1022
translate english day6_2f911a8e:

    # sb "You aren't going in there, right?"
    sb ""

# game/script.rpy:1024
translate english day6_a20cefa7:

    # "..."
    ""

# game/script.rpy:1027
translate english day6_5285390f:

    # "It's too dark to see anything."
    ""

# game/script.rpy:1030
translate english day6_7c053804:

    # "You could use your flashlight to see better."
    ""

# game/script.rpy:1045
translate english day6_1955e41e:

    # "You use Seb's soap."
    ""

# game/script.rpy:1046
translate english day6_f53d6be2:

    # "He also fixed the heater for you."
    ""

# game/script.rpy:1049
translate english day6_9841646e:

    # "The water's still cold."
    ""

# game/script.rpy:1050
translate english day6_cf261fb4:

    # "Still out of soap."
    ""

# game/script.rpy:1056
translate english day6_a4eebc7d:

    # nc "In a shocking turn of events, the earthquake has caused a massive sinkhole to open up in the downtown area, swallowing several buildings and trapping dozens of people inside. Rescue teams are currently working around the clock to extract survivors from the rubble, but the situation remains dire."
    nc ""

# game/script.rpy:1057
translate english day6_8a739473:

    # sb "Oh my God, that's crazy."
    sb ""

# game/script.rpy:1058
translate english day6_1de715b2:

    # sb "What do we do?"
    sb ""

# game/script.rpy:1073
translate english day6end_c1b87176:

    # "Better go score some snores."
    ""

# game/script.rpy:1079
translate english day7start_b4757822:

    # "It's Monday."
    ""

# game/script.rpy:1081
translate english day7start_0665efd1:

    # "You didn't have any dreams last night."
    ""

# game/script.rpy:1084
translate english day7tv_532aaef4:

    # "You decide to turn the television on."
    ""

# game/script.rpy:1087
translate english day7tv_d39f6ce7:

    # nc "The sinkhole that opened up in the downtown area has continued to expand, now measuring over twenty kilometers wide and swallowing entire cities. Rescue efforts have been hampered by the unstable ground conditions, and authorities are urging residents to stay away from the area as it remains a significant danger."
    nc ""

# game/script.rpy:1088
translate english day7tv_5bd26b71:

    # sb "Jesus christ, that's insane."
    sb ""

# game/script.rpy:1089
translate english day7tv_13c216b9:

    # sb "They said it was going to be bad, but I didn't think it would be this bad."
    sb ""

# game/script.rpy:1090
translate english day7tv_9bccbec7:

    # sb "That's the size of a fucking country."
    sb ""

# game/script.rpy:1099
translate english day7tv_4d673989:

    # "You're completely out of food."
    ""

# game/script.rpy:1100
translate english day7tv_5fe3f808:

    # "Seems like it's going to be a long day."
    ""

# game/script.rpy:1101
translate english day7tv_633180e8:

    # "It's 9:00am."
    ""

# game/script.rpy:1111
translate english day7_780cbd76:

    # "You play Bulls and Cows with Seb."
    ""

# game/script.rpy:1112
translate english day7_8e07bd27:

    # "He's okay at it."
    ""

# game/script.rpy:1114
translate english day7_ebf1c4f0:

    # "You're too hungry."
    ""

# game/script.rpy:1121
translate english day7_3512255f:

    # "No answer."
    ""

# game/script.rpy:1123
translate english day7_0fc1f2c7:

    # sb "Hey, it's Seb. I don't know if you heard, but the sinkhole has gotten really bad."
    sb ""

# game/script.rpy:1124
translate english day7_18458df3:

    # sb "Arthur left to go check on his mom."
    sb ""

# game/script.rpy:1125
translate english day7_b91d7aea:

    # sb "He said he might not be back for a while."
    sb ""

# game/script.rpy:1129
translate english day7_995dbfde:

    # "You call the number on the paper."
    ""

# game/script.rpy:1130
translate english day7_ae73fb23:

    # "It rings a few times before someone picks up."
    ""

# game/script.rpy:1131
translate english day7_006fc7ff:

    # qu "Hello?"
    qu ""

# game/script.rpy:1132
translate english day7_b034e84c:

    # qu "You missed your chance."
    qu ""

# game/script.rpy:1133
translate english day7_b3e0fdab:

    # "The line goes dead."
    ""

# game/script.rpy:1137
translate english day7_70582648:

    # "Phone" "No lines availible currently."
    "Phone" ""

# game/script.rpy:1143
translate english day7_0158349f:

    # "The hole in your wall is now gone."
    ""

# game/script.rpy:1150
translate english day7_76f0975f:

    # "You have a nice shower."
    ""

# game/script.rpy:1151
translate english day7_043de9c9:

    # "You think about the sinkhole."
    ""

# game/script.rpy:1152
translate english day7_a6e21efe:

    # "You wonder if it's going to get bigger."
    ""

# game/script.rpy:1155
translate english day7_db9d56ef:

    # "Why bother."
    ""

# game/script.rpy:1161
translate english day7_8871e001:

    # nc "The sinkhole has now reached the size of the entire country, and is continuing to expand at an alarming rate. Scientists are baffled by the phenomenon, and are struggling to understand the underlying causes. The situation is being described as unprecedented, and authorities are urging people to evacuate to higher ground as soon as possible."
    nc ""

# game/script.rpy:1185
translate english end2_9085e479:

    # centered "{color=#000000}This is the end.{/color}"
    centered ""

# game/script.rpy:1186
translate english end2_3de5697f:

    # centered "{color=#000000}The building collapses.{/color}"
    centered ""

# game/script.rpy:1187
translate english end2_d5800d0e:

    # centered "{color=#000000}You knew it was coming.{/color}"
    centered ""

# game/script.rpy:1188
translate english end2_f31f3993:

    # centered "{color=#000000}What waits for you at the bottom?{/color}"
    centered ""

# game/script.rpy:1189
translate english end2_4c8a8a59:

    # centered "{color=#000000}At least you won't be alone.{/color}"
    centered ""

# game/script.rpy:1196
translate english end2_9085e479_1:

    # centered "{color=#000000}This is the end.{/color}"
    centered ""

# game/script.rpy:1197
translate english end2_3de5697f_1:

    # centered "{color=#000000}The building collapses.{/color}"
    centered ""

# game/script.rpy:1198
translate english end2_845692bb:

    # centered "{color=#000000}You didn't even know it was coming.{/color}"
    centered ""

# game/script.rpy:1199
translate english end2_f31f3993_1:

    # centered "{color=#000000}What waits for you at the bottom?{/color}"
    centered ""

# game/script.rpy:1200
translate english end2_eba0519b:

    # centered "{color=#000000}You are alone.{/color}"
    centered ""

# game/script.rpy:1207
translate english end1_9085e479:

    # centered "{color=#000000}This is the end.{/color}"
    centered ""

# game/script.rpy:1208
translate english end1_b5c2c921:

    # centered "{color=#000000}You walk outside.{/color}"
    centered ""

# game/script.rpy:1209
translate english end1_e5baa7ac:

    # centered "{color=#000000}Everything is burning.{/color}"
    centered ""

# game/script.rpy:1210
translate english end1_97fc73f9:

    # centered "{color=#000000}You feel the ground shake.{/color}"
    centered ""

# game/script.rpy:1211
translate english end1_2dcc7a39:

    # centered "{color=#000000}The sky is grey with smoke.{/color}"
    centered ""

# game/script.rpy:1212
translate english end1_af158432:

    # centered "{color=#000000}You never thought there would be a day like this.{/color}"
    centered ""

# game/script.rpy:1213
translate english end1_ab6e19be:

    # centered "{color=#000000}You can't do anything now.{/color}"
    centered ""

# game/script.rpy:1214
translate english end1_eba0519b:

    # centered "{color=#000000}You are alone.{/color}"
    centered ""

# game/script.rpy:1222
translate english tunnel_5e897ac8:

    # "You walk through the hole in the wall."
    ""

# game/script.rpy:1223
translate english tunnel_2d79148a:

    # "The tunnel is dark and narrow."
    ""

# game/script.rpy:1224
translate english tunnel_9de81a61:

    # "You can barely see anything."
    ""

# game/script.rpy:1228
translate english tunnel_c314321e:

    # "You keep walking through the tunnel."
    ""

# game/script.rpy:1230
translate english tunnel_e7172d81:

    # "You see a faint light."
    ""

# game/script.rpy:1235
translate english tunnel_bc622b90:

    # qu "Welcome."
    qu ""

# game/script.rpy:1236
translate english tunnel_13897db5:

    # qu "I have waited for you."
    qu ""

# game/script.rpy:1237
translate english tunnel_8ee89deb:

    # qu "How long have you been waiting?"
    qu ""

# game/script.rpy:1238
translate english tunnel_9cc64295:

    # qu "A long time."
    qu ""

# game/script.rpy:1239
translate english tunnel_3bb94f91:

    # qu "One word answer."
    qu ""

# game/script.rpy:1240
translate english tunnel_d4eaab40:

    # qu "What can go around the world but stay in a corner?"
    qu ""

# game/script.rpy:1244
translate english tunnel_aca6a91b:

    # qu "Yes."
    qu ""

# game/script.rpy:1247
translate english tunnel_aca6a91b_1:

    # qu "Yes."
    qu ""

# game/script.rpy:1250
translate english tunnel_aca6a91b_2:

    # qu "Yes."
    qu ""

# game/script.rpy:1253
translate english tunnel_16132fc0:

    # qu "Incorrect."
    qu ""

# game/script.rpy:1254
translate english tunnel_be769c77:

    # qu "What a shame."
    qu ""

# game/script.rpy:1255
translate english tunnel_9ae983ba:

    # qu "Goodbye."
    qu ""

# game/script.rpy:1259
translate english q2_3bb94f91:

    # qu "One word answer."
    qu ""

# game/script.rpy:1260
translate english q2_ab4d260e:

    # qu "Where can you finish a book without finishing a sentence?"
    qu ""

# game/script.rpy:1264
translate english q2_aca6a91b:

    # qu "Yes."
    qu ""

# game/script.rpy:1267
translate english q2_aca6a91b_1:

    # qu "Yes."
    qu ""

# game/script.rpy:1270
translate english q2_aca6a91b_2:

    # qu "Yes."
    qu ""

# game/script.rpy:1273
translate english q2_16132fc0:

    # qu "Incorrect."
    qu ""

# game/script.rpy:1274
translate english q2_be769c77:

    # qu "What a shame."
    qu ""

# game/script.rpy:1275
translate english q2_9ae983ba:

    # qu "Goodbye."
    qu ""

# game/script.rpy:1280
translate english q3_3bb94f91:

    # qu "One word answer."
    qu ""

# game/script.rpy:1281
translate english q3_d1c4afbe:

    # qu "What goes up a chimney down, but not down a chimney up?"
    qu ""

# game/script.rpy:1285
translate english q3_aca6a91b:

    # qu "Yes."
    qu ""

# game/script.rpy:1288
translate english q3_aca6a91b_1:

    # qu "Yes."
    qu ""

# game/script.rpy:1291
translate english q3_aca6a91b_2:

    # qu "Yes."
    qu ""

# game/script.rpy:1294
translate english q3_16132fc0:

    # qu "Incorrect."
    qu ""

# game/script.rpy:1295
translate english q3_be769c77:

    # qu "What a shame."
    qu ""

# game/script.rpy:1296
translate english q3_9ae983ba:

    # qu "Goodbye."
    qu ""

# game/script.rpy:1301
translate english q4_3bb94f91:

    # qu "One word answer."
    qu ""

# game/script.rpy:1302
translate english q4_463cb0cf:

    # qu "An electric train is traveling south at 100 mph. The wind is blowing from the west at 20 mph. Which way does the smoke blow?"
    qu ""

# game/script.rpy:1310
translate english q4_d23b6a2a:

    # qu "{cps=10}We will all miss the earth.{/cps}"
    qu ""

# game/script.rpy:1311
translate english q4_0aecf87c:

    # qu "{cps=10}All but me.{/cps}"
    qu ""

# game/script.rpy:1312
translate english q4_f3fca36b:

    # qu "{cps=10}I'll be gone.{/cps}"
    qu ""

# game/script.rpy:1313
translate english q4_0a364f9b:

    # qu "{cps=10}And then you.{/cps}"
    qu ""

# game/script.rpy:1314
translate english q4_72785b5a:

    # qu "{cps=10}Goodbye.{/cps}"
    qu ""

# game/script.rpy:1322
translate english q4_16132fc0:

    # qu "Incorrect."
    qu ""

# game/script.rpy:1323
translate english q4_d1bc2912:

    # qu "You have not pleased the masses."
    qu ""

# game/script.rpy:1324
translate english q4_9ae983ba:

    # qu "Goodbye."
    qu ""

# game/script.rpy:1328
translate english q4_16132fc0_1:

    # qu "Incorrect."
    qu ""

# game/script.rpy:1329
translate english q4_be769c77:

    # qu "What a shame."
    qu ""

# game/script.rpy:1330
translate english q4_9ae983ba_1:

    # qu "Goodbye."
    qu ""

translate english strings:

    # game/script.rpy:130
    old "Fine."
    new ""

    # game/script.rpy:133
    old "Bad."
    new ""

    # game/script.rpy:141
    old "Yeah."
    new ""

    # game/script.rpy:145
    old "Do you know what's going on?"
    new ""

    # game/script.rpy:162
    old "Play the crossword."
    new ""

    # game/script.rpy:166
    old "Call someone."
    new ""

    # game/script.rpy:169
    old "Call your neighbour."
    new ""

    # game/script.rpy:172
    old "This is your neighbour. Just checking if this number is right."
    new ""

    # game/script.rpy:177
    old "This is a ghost."
    new ""

    # game/script.rpy:180
    old "Call 911."
    new ""

    # game/script.rpy:183
    old "Nevermind."
    new ""

    # game/script.rpy:185
    old "Clean up."
    new ""

    # game/script.rpy:189
    old "Take a shower."
    new ""

    # game/script.rpy:195
    old "Watch TV."
    new ""

    # game/script.rpy:202
    old "Go to bed."
    new ""

    # game/script.rpy:218
    old "Try to remember."
    new ""

    # game/script.rpy:234
    old "Get on with your day."
    new ""

    # game/script.rpy:252
    old "Sure."
    new ""

    # game/script.rpy:254
    old "You look horrible."
    new ""

    # game/script.rpy:256
    old "What's with the huge hat?"
    new ""

    # game/script.rpy:262
    old "Who are you?"
    new ""

    # game/script.rpy:265
    old "Scram."
    new ""

    # game/script.rpy:288
    old "Play sudoku."
    new ""

    # game/script.rpy:298
    old "There is some weird guy going around with a huge hat. Have you seen him?"
    new ""

    # game/script.rpy:304
    old "What is \"Phage\"?"
    new ""

    # game/script.rpy:393
    old "Yes."
    new ""

    # game/script.rpy:399
    old "No."
    new ""

    # game/script.rpy:412
    old "Open the door."
    new ""

    # game/script.rpy:420
    old "Keep quiet."
    new ""

    # game/script.rpy:448
    old "Yeah sure, here."
    new ""

    # game/script.rpy:451
    old "Shouldn't you be inside?"
    new ""

    # game/script.rpy:461
    old "Play shikaku."
    new ""

    # game/script.rpy:471
    old "Nothing much. How are you doing?"
    new ""

    # game/script.rpy:488
    old "Look through the hole."
    new ""

    # game/script.rpy:491
    old "Ignore it."
    new ""

    # game/script.rpy:559
    old "Who is Colin?"
    new ""

    # game/script.rpy:563
    old "What happened?"
    new ""

    # game/script.rpy:596
    old "Take the flashlight."
    new ""

    # game/script.rpy:600
    old "Refuse."
    new ""

    # game/script.rpy:613
    old "Play wordsearch."
    new ""

    # game/script.rpy:621
    old "Call Arthur."
    new ""

    # game/script.rpy:630
    old "Some man dressed in a police uniform just killed my neighbour."
    new ""

    # game/script.rpy:633
    old "Do you know what is going on?"
    new ""

    # game/script.rpy:650
    old "Use the flashlight."
    new ""

    # game/script.rpy:729
    old "Yeah, sure, come on in."
    new ""

    # game/script.rpy:735
    old "What stuff do you have?"
    new ""

    # game/script.rpy:739
    old "Get lost."
    new ""

    # game/script.rpy:749
    old "Okay."
    new ""

    # game/script.rpy:768
    old "Keep it closed."
    new ""

    # game/script.rpy:771
    old "No. Stop bothering me."
    new ""

    # game/script.rpy:787
    old "Play Dots and Boxes."
    new ""

    # game/script.rpy:801
    old "I let in this guy named Seb."
    new ""

    # game/script.rpy:806
    old "This guy named Seb came around asking to come in."
    new ""

    # game/script.rpy:951
    old "Take piece of paper."
    new ""

    # game/script.rpy:981
    old "Play Hangman."
    new ""

    # game/script.rpy:996
    old "You should come over sometime."
    new ""

    # game/script.rpy:1001
    old "Call the number on the paper."
    new ""

    # game/script.rpy:1026
    old "Walk through the hole."
    new ""

    # game/script.rpy:1109
    old "Play Bulls and Cows."
    new ""

    # game/script.rpy:1226
    old "Keep walking."
    new ""

    # game/script.rpy:1336
    old "Turn around and go back."
    new ""

